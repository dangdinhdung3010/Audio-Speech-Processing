import os
import sys
import pickle
from pathlib import Path
import numpy as np
from hmmlearn.hmm import GaussianHMM

from step2_feature_extraction import extract_feat

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

LABELS = ['mo', 'dong', 'len', 'xuong', 'dung']

def make_lr_hmm(n_states=5, n_iter=80, params='mc', random_state=0):
    """
    Khởi tạo mô hình Left-to-Right Gaussian HMM theo đúng yêu cầu Lab 3:
    - n_components = n_states
    - covariance_type = 'diag' (tiết kiệm tham số, tránh overfit khi ít dữ liệu)
    - startprob_ = [1.0, 0, ..., 0] (luôn bắt đầu ở trạng thái đầu)
    - transmat_: a_ii = 0.7, a_i,i+1 = 0.3, a_N,N = 1.0 (trái-sang-phải nghiêm ngặt)
    - params: 'mc' khóa cố định transition matrix để bảo toàn topology cấu trúc,
      hoặc 'tmc' cập nhật cả transition matrix.
    """
    model = GaussianHMM(
        n_components=n_states,
        covariance_type='diag',
        n_iter=n_iter,
        tol=1e-3,
        min_covar=1e-3,
        init_params='mc',
        params=params,
        random_state=random_state
    )
    
    # 1. Vector xác suất ban đầu: Bắt buộc bắt đầu ở trạng thái 0
    start = np.zeros(n_states)
    start[0] = 1.0
    model.startprob_ = start
    
    # 2. Ma trận chuyển trạng thái trái-sang-phải
    A = np.zeros((n_states, n_states))
    for i in range(n_states - 1):
        A[i, i] = 0.7
        A[i, i + 1] = 0.3
    A[-1, -1] = 1.0
    model.transmat_ = A
    
    return model

def train_models(n_states=5, data_dir='dataset/train', params='mc'):
    """
    Huấn luyện 5 mô hình HMM độc lập cho 5 từ lệnh.
    """
    print("=" * 68)
    print(f"BƯỚC 3: HUẤN LUYỆN 5 WHOLE-WORD GAUSSIAN HMM (n_states={n_states}, params='{params}')")
    print("=" * 68)
    
    models = {}
    
    for label in LABELS:
        wav_files = sorted(Path(data_dir, label).glob('*.wav'))
        if not wav_files:
            print(f"[!] Không tìm thấy file trong {data_dir}/{label}")
            continue
            
        feats = []
        lengths = []
        for wav in wav_files:
            F = extract_feat(str(wav))
            feats.append(F)
            lengths.append(len(F))
            
        # Ghép các chuỗi phát âm thành ma trận X_concat lớn
        X_concat = np.vstack(feats)
        total_frames = sum(lengths)
        
        # Khởi tạo HMM
        model = make_lr_hmm(n_states=n_states, params=params)
        
        # Huấn luyện Baum-Welch (EM)
        model.fit(X_concat, lengths)
        models[label] = model
        
        # Đánh giá hội tụ và log-likelihood
        converged = model.monitor_.converged
        iters = model.monitor_.iter
        logL = model.score(X_concat, lengths)
        
        print(f"\n[+] Huấn luyện từ: '{label.upper()}' ({len(wav_files)} file, {total_frames} khung)")
        print(f"    - Trạng thái hội tụ (Converged): {converged} (sau {iters} vòng lặp EM)")
        print(f"    - Tổng Log-Likelihood: {logL:10.2f}  |  TB: {logL / total_frames:.2f} / frame")
        print(f"    - Ma trận transmat_ sau fit:")
        print(np.round(model.transmat_, 3))
        
        # Kiểm tra bảo toàn topology (không có phần tử nào nhảy lùi j < i hoặc skip j > i+1)
        valid_topology = True
        for i in range(n_states):
            for j in range(n_states):
                if (j < i or j > i + 1) and model.transmat_[i, j] > 1e-5:
                    valid_topology = False
        status_str = "HỢP LỆ (Không nhảy lùi / không skip)" if valid_topology else "CẢNH BÁO: VI PHẠM"
        print(f"    - Cấu trúc Left-to-Right: {status_str}")

    # Tạo thư mục models/ và lưu lại các mô hình
    os.makedirs('models', exist_ok=True)
    save_path = 'models/hmm_models.pkl'
    with open(save_path, 'wb') as f:
        pickle.dump(models, f)
        
    print("\n" + "=" * 68)
    print(f"-> Đã lưu thành công 5 mô hình HMM vào: {save_path}")
    print("=" * 68)
    return models

if __name__ == '__main__':
    models = train_models(n_states=5, params='mc')
