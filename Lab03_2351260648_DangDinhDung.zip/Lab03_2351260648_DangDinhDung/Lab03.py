"""
TRƯỜNG ĐẠI HỌC THỦY LỢI - KHOA CÔNG NGHỆ THÔNG TIN - BỘ MÔN TRÍ TUỆ NHÂN TẠO
HỌC PHẦN: CSE457 - XỬ LÝ ÂM THANH VÀ TIẾNG NÓI
BÀI THỰC HÀNH SỐ 3: NHẬN DẠNG TIẾNG NÓI NÂNG CAO VỚI HMM
Sinh viên thực hiện: Đặng Đình Dũng
Mã sinh viên: 2351260648
"""

import os
import sys
import math
import time
import pickle
from pathlib import Path

import numpy as np
import soundfile as sf
import librosa
import matplotlib.pyplot as plt
from scipy.spatial.distance import cdist
from sklearn.metrics import accuracy_score, confusion_matrix, ConfusionMatrixDisplay
from hmmlearn.hmm import GaussianHMM

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

# Cấu hình danh sách nhãn từ lệnh tiếng Việt
LABELS = ['mo', 'dong', 'len', 'xuong', 'dung']
TARGET_SR = 16000

# ==============================================================================
# PHẦN 1: TRÍCH XUẤT ĐẶC TRƯNG 39 CHIỀU (MFCC + DELTA + DELTA-DELTA + CMVN)
# ==============================================================================
def extract_feat(path, sr=TARGET_SR):
    """
    Trích xuất đặc trưng 39 chiều:
    1. Đọc tín hiệu WAV mono Fs = 16kHz
    2. Cắt khoảng lặng đầu/cuối bằng trim (top_db=30)
    3. Lọc tiền nhấn pre-emphasis (coef=0.97)
    4. Trích xuất 13 MFCC tĩnh (win=25ms, hop=10ms, n_fft=512, n_mels=26, hamming)
    5. Đạo hàm bậc 1 (Delta) và bậc 2 (Delta-Delta)
    6. Chuẩn hóa CMVN cấp utterance: (F - mu) / sd
    """
    y, sr = librosa.load(path, sr=sr, mono=True)
    y, _ = librosa.effects.trim(y, top_db=30)
    y = librosa.effects.preemphasis(y, coef=0.97)
    
    mfcc = librosa.feature.mfcc(
        y=y, sr=sr, n_mfcc=13,
        n_fft=512, win_length=int(0.025 * sr),
        hop_length=int(0.010 * sr), window='hamming',
        n_mels=26, fmin=20, fmax=sr / 2
    )
    d1 = librosa.feature.delta(mfcc, order=1)
    d2 = librosa.feature.delta(mfcc, order=2)
    
    F = np.vstack([mfcc, d1, d2]).T  # T x 39
    mu = F.mean(axis=0, keepdims=True)
    sd = F.std(axis=0, keepdims=True) + 1e-8
    return (F - mu) / sd

# ==============================================================================
# PHẦN 2: KHỞI TẠO VÀ HUẤN LUYỆN MÔ HÌNH LEFT-TO-RIGHT GAUSSIAN HMM
# ==============================================================================
def make_lr_hmm(n_states=5, n_iter=80, params='mc', random_state=0):
    """
    Khởi tạo mô hình Left-to-Right Gaussian HMM:
    - n_components = n_states
    - covariance_type = 'diag'
    - startprob_ = [1.0, 0, ..., 0]
    - transmat_: a_ii = 0.7, a_i,i+1 = 0.3, a_N,N = 1.0
    - params = 'mc': cố định transmat để bảo toàn topology cấm nhảy lùi/skip
    """
    model = GaussianHMM(
        n_components=n_states,
        covariance_type='diag',
        n_iter=n_iter, tol=1e-3, min_covar=1e-3,
        init_params='mc', params=params, random_state=random_state
    )
    start = np.zeros(n_states)
    start[0] = 1.0
    model.startprob_ = start
    
    A = np.zeros((n_states, n_states))
    for i in range(n_states - 1):
        A[i, i] = 0.7
        A[i, i + 1] = 0.3
    A[-1, -1] = 1.0
    model.transmat_ = A
    return model

def train_all_models(n_states=5, data_dir='dataset/train'):
    """Huấn luyện 5 mô hình HMM độc lập bằng thuật toán Baum-Welch (EM)."""
    models = {}
    for label in LABELS:
        wav_files = sorted(Path(data_dir, label).glob('*.wav'))
        feats = [extract_feat(str(w)) for w in wav_files]
        lengths = [len(f) for f in feats]
        X = np.vstack(feats)
        
        model = make_lr_hmm(n_states=n_states, params='mc')
        model.fit(X, lengths)
        models[label] = model
        print(f"  [Train] Từ '{label:6s}': Converged={model.monitor_.converged}, iters={model.monitor_.iter}, LL/frame={model.score(X, lengths)/sum(lengths):.2f}")
    
    os.makedirs('models', exist_ok=True)
    with open('models/hmm_models.pkl', 'wb') as f:
        pickle.dump(models, f)
    return models

# ==============================================================================
# PHẦN 3: NHẬN DẠNG MAXIMUM LIKELIHOOD VÀ CĂN CHỈNH VITERBI
# ==============================================================================
def recognize(path, models):
    """Quy tắc quyết định Maximum Likelihood (ML)"""
    F = extract_feat(path)
    scores = {label: float(model.score(F)) for label, model in models.items()}
    pred = max(scores, key=scores.get)
    return pred, scores, F

# ==============================================================================
# PHẦN 4: BASELINE ĐỐI CHIẾU DTW (LAB 2)
# ==============================================================================
def compute_dtw_distance(feat1, feat2):
    """Tính khoảng cách DTW chuẩn hóa bằng quy hoạch động"""
    T1, T2 = len(feat1), len(feat2)
    dist_matrix = cdist(feat1, feat2, metric='euclidean')
    cost = np.full((T1 + 1, T2 + 1), np.inf)
    cost[0, 0] = 0.0
    for i in range(1, T1 + 1):
        for j in range(1, T2 + 1):
            cost[i, j] = dist_matrix[i - 1, j - 1] + min(cost[i - 1, j], cost[i, j - 1], cost[i - 1, j - 1])
    return cost[T1, T2] / (T1 + T2)

def dtw_classify(test_feat, train_templates):
    best_dist = float('inf')
    best_label = None
    for train_lbl, train_feat in train_templates:
        d = compute_dtw_distance(test_feat, train_feat)
        if d < best_dist:
            best_dist = d
            best_label = train_lbl
    return best_label, best_dist

# ==============================================================================
# PHẦN 5: LEXICON VÀ BIGRAM MAP RE-RANKING
# ==============================================================================
def parse_lexicon(filepath="lexicon.txt"):
    lexicon = {}
    with open(filepath, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):
                parts = line.split()
                lexicon[parts[0]] = parts[1:]
    return lexicon

def bigram_prob(prev, cur, counts2, counts1, V=5, k=0.5):
    return (counts2.get((prev, cur), 0) + k) / (counts1.get(prev, 0) + k * V)

def rerank(F, prev, models, counts2, counts1, lm_weight=0.3):
    T = len(F)
    V = len(models)
    total = {}
    for w, m in models.items():
        a = m.score(F) / T
        lm = math.log(bigram_prob(prev, w, counts2, counts1, V, k=0.5))
        total[w] = a + lm_weight * lm
    return max(total, key=total.get), total

# ==============================================================================
# HÀM CHẠY TỔNG HỢP TOÀN BỘ PIPELINE
# ==============================================================================
def main():
    print("=" * 75)
    print("CHƯƠNG TRÌNH NHẬN DẠNG TIẾNG NÓI NÂNG CAO VỚI HMM - LAB 3 (CSE457)")
    print("Sinh viên: Đặng Đình Dũng - MSV: 2351260648")
    print("=" * 75)
    
    # 1. Trích xuất đặc trưng mẫu
    sample_feat = extract_feat('dataset/train/mo/mo_01.wav')
    print(f"\n[1] Kiểm tra trích xuất đặc trưng: mo_01.wav -> Shape: {sample_feat.shape} (T={sample_feat.shape[0]}, D={sample_feat.shape[1]})")
    
    # 2. Huấn luyện 5 mô hình HMM
    print("\n[2] Bắt đầu huấn luyện 5 mô hình Whole-word HMM:")
    models = train_all_models(n_states=5)
    
    # 3. Đánh giá trên tập test
    print("\n[3] Đánh giá trên tập Test (HMM vs DTW):")
    # Load DTW templates
    train_templates = []
    for l in LABELS:
        for w in sorted(Path('dataset/train', l).glob('*.wav')):
            train_templates.append((l, extract_feat(str(w))))
            
    true_y, pred_hmm, pred_dtw = [], [], []
    t_hmm_list, t_dtw_list = [], []
    
    for l in LABELS:
        for tw in sorted(Path('dataset/test', l).glob('*.wav')):
            F = extract_feat(str(tw))
            true_y.append(l)
            
            # HMM
            t0 = time.perf_counter()
            pred_h, scores, _ = recognize(str(tw), models)
            t_hmm_list.append(time.perf_counter() - t0)
            pred_hmm.append(pred_h)
            
            # DTW
            t0 = time.perf_counter()
            pred_d, _ = dtw_classify(F, train_templates)
            t_dtw_list.append(time.perf_counter() - t0)
            pred_dtw.append(pred_d)
            
    acc_hmm = accuracy_score(true_y, pred_hmm)
    acc_dtw = accuracy_score(true_y, pred_dtw)
    print(f"  -> HMM Accuracy: {acc_hmm*100:.1f}% | Thời gian TB: {np.mean(t_hmm_list)*1000:.2f} ms/mẫu")
    print(f"  -> DTW Accuracy: {acc_dtw*100:.1f}% | Thời gian TB: {np.mean(t_dtw_list)*1000:.2f} ms/mẫu")
    print(f"  -> Tốc độ: HMM nhanh hơn DTW gấp ~{np.mean(t_dtw_list)/np.mean(t_hmm_list):.1f} lần!")
    
    # 4. Lexicon & Bigram Demo
    print("\n[4] Kiểm tra Lexicon và Bigram Re-ranking:")
    lexicon = parse_lexicon("lexicon.txt")
    print(f"  - Đã nạp từ điển: {len(lexicon)} từ vựng.")
    corpus = ["<s> thang_may len </s>", "<s> thang_may xuong </s>", "<s> thang_may len </s>", "<s> khan_cap dung </s>"]
    c1, c2 = {}, {}
    for s in corpus:
        ws = s.split()
        for i, w in enumerate(ws):
            c1[w] = c1.get(w, 0) + 1
            if i > 0: c2[(ws[i-1], w)] = c2.get((ws[i-1], w), 0) + 1
            
    test_f = extract_feat('dataset/test/len/len_07.wav')
    best_w, totals = rerank(test_f, 'thang_may', models, c2, c1, lm_weight=0.3)
    print(f"  - Re-ranking trong ngữ cảnh 'thang_may': Dự đoán -> '{best_w}' (Score: {totals[best_w]:.3f})")
    print("\n" + "=" * 75)
    print("HOÀN TẤT CHẠY TOÀN BỘ PIPELINE LAB 3 THÀNH CÔNG!")
    print("=" * 75)

if __name__ == '__main__':
    main()
