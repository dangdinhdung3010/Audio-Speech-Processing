import os
import sys
import pickle
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

from step2_feature_extraction import extract_feat

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

LABELS = ['mo', 'dong', 'len', 'xuong', 'dung']

def load_models(model_path='models/hmm_models.pkl'):
    """Tải 5 mô hình HMM đã huấn luyện từ Bước 3."""
    with open(model_path, 'rb') as f:
        models = pickle.load(f)
    return models

def recognize(path, models):
    """
    Nhận dạng một file âm thanh bằng Maximum Likelihood:
    s_w(X) = log P(X | lambda_w)
    w* = argmax_w s_w(X)
    """
    F = extract_feat(path)
    scores = {label: float(model.score(F)) for label, model in models.items()}
    pred = max(scores, key=scores.get)
    return pred, scores, F

def run_step4():
    print("=" * 70)
    print("BƯỚC 4: NHẬN DẠNG MAXIMUM LIKELIHOOD VÀ PHÂN TÍCH VITERBI ALIGNMENT")
    print("=" * 70)
    
    models = load_models()
    
    # 1. Bảng thống kê điểm acoustic score cho các file test
    test_files = [
        ('dataset/test/mo/mo_07.wav', 'mo', 'Lệnh "mở" (mo_07)'),
        ('dataset/test/dong/dong_07.wav', 'dong', 'Lệnh "đóng" (dong_07)'),
        ('dataset/test/len/len_07.wav', 'len', 'Lệnh "lên" (len_07)'),
        ('dataset/test/xuong/xuong_07.wav', 'xuong', 'Lệnh "xuống" (xuong_07)'),
        ('dataset/test/dung/dung_07.wav', 'dung', 'Lệnh "dừng" (dung_07)'),
    ]
    
    print("\n[1] BẢNG ĐIỂM ACOUSTIC LOG-LIKELIHOOD SCORE TRÊN TẬP TEST:")
    header = f"{'File kiểm thử':<22} | {'True':<6} | " + " | ".join([f"{l:>9}" for l in LABELS]) + " | {'Top-1':<6} | {'Khoảng cách Top 1-2'}"
    print("-" * len(header))
    print(header)
    print("-" * len(header))
    
    for fpath, true_label, desc in test_files:
        pred, scores, _ = recognize(fpath, models)
        # Sắp xếp điểm giảm dần
        sorted_scores = sorted(scores.items(), key=lambda z: z[1], reverse=True)
        top1_lbl, top1_sc = sorted_scores[0]
        top2_lbl, top2_sc = sorted_scores[1]
        gap = top1_sc - top2_sc
        
        row_scores = " | ".join([f"{scores[l]:9.2f}" for l in LABELS])
        status = "[ĐÚNG]" if pred == true_label else "[SAI]"
        print(f"{Path(fpath).name:<22} | {true_label:<6} | {row_scores} | {pred:<6} | Delta = {gap:7.2f} {status}")
        
    print("-" * len(header))
    
    # 2. Phân tích chi tiết 3 file test tiêu biểu
    print("\n[2] PHÂN TÍCH CHI TIẾT 3 MẪU KIỂM THỬ TIÊU BIỂU:")
    for fpath, true_label, desc in test_files[:3]:
        pred, scores, F = recognize(fpath, models)
        sorted_scores = sorted(scores.items(), key=lambda z: z[1], reverse=True)
        top1_lbl, top1_sc = sorted_scores[0]
        top2_lbl, top2_sc = sorted_scores[1]
        gap = top1_sc - top2_sc
        T = len(F)
        
        print(f"\n  * Utterance: {desc} (T = {T} frames)")
        print(f"    - Nhãn dự đoán (argmax): '{pred}' (Mô hình có log-likelihood cực đại)")
        print(f"    - Bảng xếp hạng điểm (Ranking):")
        for rank, (lbl, sc) in enumerate(sorted_scores, 1):
            mark = " <-- CHỌN (Top-1)" if rank == 1 else (" <-- Á quân (Top-2)" if rank == 2 else "")
            print(f"        {rank}. {lbl:6s}: {sc:10.2f} (TB: {sc/T:6.2f}/frame){mark}")
        print(f"    - Phân tích khoảng cách: Top-1 vượt trội Top-2 một khoảng Δ = {gap:.2f} điểm.")
        print(f"      Tỉ lệ tin cậy (Bayes posterior ratio): exp(Δ) ≈ 10^{gap / 2.3026:.1f} lần!")
        
    # 3. Trích xuất và vẽ căn chỉnh trạng thái Viterbi (Viterbi Alignment)
    print("\n[3] TRÍCH XUẤT VÀ VẼ CĂN CHỈNH TRẠNG THÁI VITERBI (VITERBI ALIGNMENT):")
    viterbi_samples = [
        ('dataset/test/mo/mo_07.wav', 'mo', 'mo_07.wav ("mở")'),
        ('dataset/test/dong/dong_07.wav', 'dong', 'dong_07.wav ("đóng")'),
        ('dataset/test/len/len_07.wav', 'len', 'len_07.wav ("lên")'),
    ]
    
    fig, axes = plt.subplots(1, 3, figsize=(16, 5))
    fig.suptitle('Căn chỉnh chuỗi trạng thái Viterbi (Viterbi State Alignment) theo thời gian', fontsize=14, fontweight='bold')
    
    viterbi_results = []
    for idx, (fpath, label, title) in enumerate(viterbi_samples):
        F = extract_feat(fpath)
        logp, states = models[label].decode(F, algorithm='viterbi')
        viterbi_results.append((fpath, label, logp, states, F))
        
        # Vẽ step plot
        ax = axes[idx]
        ax.step(range(len(states)), states, where='post', color='#1f77b4', linewidth=2.5)
        ax.set_title(f"{title}\nViterbi log-prob: {logp:.1f}", fontsize=11, fontweight='semibold')
        ax.set_xlabel('Chỉ số khung (Frame Index - 10ms/frame)')
        ax.set_ylabel('Chỉ số trạng thái HMM (State Index)')
        ax.set_yticks(range(5))
        ax.set_yticklabels([f"State {i}" for i in range(5)])
        ax.grid(True, linestyle='--', alpha=0.6)
        
        # Thống kê duration từng state
        unique, counts = np.unique(states, return_counts=True)
        durations = dict(zip(unique, counts))
        print(f"\n  * Căn chỉnh Viterbi cho {title}:")
        print(f"    - Tổng số frame: {len(states)} (tương đương {len(states) * 10} ms)")
        print(f"    - Viterbi Log-likelihood: {logp:.2f}")
        print(f"    - Chuỗi trạng thái: {states.tolist()}")
        print(f"    - Thời lượng (frame) tại mỗi trạng thái:")
        for s in range(5):
            cnt = durations.get(s, 0)
            print(f"        State {s}: {cnt:2d} frames ({cnt * 10:3d} ms) | Chiếm {cnt / len(states) * 100:5.1f}%")
            
    plt.tight_layout()
    viterbi_plot_path = 'viterbi_alignment.png'
    plt.savefig(viterbi_plot_path, dpi=200)
    plt.close()
    print(f"\n-> Đã lưu biểu đồ Viterbi alignment tại: {viterbi_plot_path}")
    print("=" * 70)

if __name__ == '__main__':
    run_step4()
