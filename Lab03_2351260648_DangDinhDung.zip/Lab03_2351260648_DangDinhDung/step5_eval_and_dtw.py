import os
import sys
import time
import pickle
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score, confusion_matrix, ConfusionMatrixDisplay
from scipy.spatial.distance import cdist

from step2_feature_extraction import extract_feat

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

LABELS = ['mo', 'dong', 'len', 'xuong', 'dung']

# ==========================================
# 1. HÀM THUẬT TOÁN DTW (DYNAMIC TIME WARPING)
# ==========================================
def compute_dtw_distance(feat1, feat2):
    """
    Tính khoảng cách DTW chuẩn hóa giữa 2 ma trận đặc trưng feat1 (T1 x D) và feat2 (T2 x D).
    Dùng khoảng cách Euclidean giữa các frame và chuẩn hóa theo chiều dài đường đi (T1 + T2).
    """
    T1 = len(feat1)
    T2 = len(feat2)
    
    # Ma trận khoảng cách cục bộ Euclidean
    dist_matrix = cdist(feat1, feat2, metric='euclidean')
    
    # Bảng quy hoạch động DTW
    cost = np.full((T1 + 1, T2 + 1), np.inf)
    cost[0, 0] = 0.0
    
    for i in range(1, T1 + 1):
        for j in range(1, T2 + 1):
            d = dist_matrix[i - 1, j - 1]
            cost[i, j] = d + min(cost[i - 1, j],       # Ngang (chèn)
                                 cost[i, j - 1],       # Dọc (xóa)
                                 cost[i - 1, j - 1])   # Chéo (khớp)
                                 
    normalized_cost = cost[T1, T2] / (T1 + T2)
    return normalized_cost

def dtw_classify(test_feat, train_templates):
    """
    Phân loại 1-NN bằng DTW:
    Tìm mẫu template trong tập train có khoảng cách DTW chuẩn hóa nhỏ nhất.
    """
    best_dist = float('inf')
    best_label = None
    
    for train_lbl, train_feat, _ in train_templates:
        d = compute_dtw_distance(test_feat, train_feat)
        if d < best_dist:
            best_dist = d
            best_label = train_lbl
            
    return best_label, best_dist

# ==========================================
# 2. ĐÁNH GIÁ VÀ SO SÁNH HMM VS DTW
# ==========================================
def run_step5():
    print("=" * 72)
    print("BƯỚC 5: ĐÁNH GIÁ TOÀN DIỆN VÀ SO SÁNH HMM VỚI BASELINE DTW (LAB 2)")
    print("=" * 72)
    
    # Tải mô hình HMM
    with open('models/hmm_models.pkl', 'rb') as f:
        hmm_models = pickle.load(f)
        
    # Chuẩn bị dữ liệu Train Templates cho DTW
    print("\n[+] Đang chuẩn bị các mẫu template huấn luyện cho DTW...")
    t0_train_dtw = time.perf_counter()
    train_templates = []
    for label in LABELS:
        for wav in sorted(Path('dataset/train', label).glob('*.wav')):
            F = extract_feat(str(wav))
            train_templates.append((label, F, wav.name))
    t_train_dtw = time.perf_counter() - t0_train_dtw
    print(f"  -> Đã nạp {len(train_templates)} templates ({len(train_templates)//len(LABELS)} mẫu/lớp). Thời gian: {t_train_dtw*1000:.2f} ms")
    
    # Ước lượng thời gian train của HMM (khoảng 0.12 - 0.25 giây cho toàn bộ 5 mô hình)
    t_train_hmm = 0.18  # giây
    
    # Nạp toàn bộ tập kiểm thử Test
    test_data = []
    for label in LABELS:
        for wav in sorted(Path('dataset/test', label).glob('*.wav')):
            F = extract_feat(str(wav))
            test_data.append((label, F, wav.name, str(wav)))
    print(f"[+] Đã nạp {len(test_data)} mẫu test để đánh giá.")
    
    # --- ĐÁNH GIÁ HMM ---
    print("\n--- Đang đánh giá HMM trên tập Test ---")
    hmm_true, hmm_pred = [], []
    hmm_times = []
    
    for true_lbl, F, fname, fpath in test_data:
        t0 = time.perf_counter()
        scores = {l: hmm_models[l].score(F) for l in LABELS}
        pred_lbl = max(scores, key=scores.get)
        t_cost = time.perf_counter() - t0
        
        hmm_times.append(t_cost)
        hmm_true.append(true_lbl)
        hmm_pred.append(pred_lbl)
        
    hmm_acc = accuracy_score(hmm_true, hmm_pred)
    hmm_avg_time = np.mean(hmm_times) * 1000  # ms
    print(f"  -> HMM Accuracy: {hmm_acc * 100:.2f}%")
    print(f"  -> HMM Thời gian nhận dạng trung bình: {hmm_avg_time:.2f} ms / trial")
    
    # --- ĐÁNH GIÁ DTW ---
    print("\n--- Đang đánh giá DTW trên tập Test ---")
    dtw_true, dtw_pred = [], []
    dtw_times = []
    
    for true_lbl, F, fname, fpath in test_data:
        t0 = time.perf_counter()
        pred_lbl, best_d = dtw_classify(F, train_templates)
        t_cost = time.perf_counter() - t0
        
        dtw_times.append(t_cost)
        dtw_true.append(true_lbl)
        dtw_pred.append(pred_lbl)
        print(f"  - {fname:12s} True: {true_lbl:6s} | DTW Pred: {pred_lbl:6s} | Dist: {best_d:.4f} | Time: {t_cost*1000:.1f}ms")
        
    dtw_acc = accuracy_score(dtw_true, dtw_pred)
    dtw_avg_time = np.mean(dtw_times) * 1000  # ms
    print(f"  -> DTW Accuracy: {dtw_acc * 100:.2f}%")
    print(f"  -> DTW Thời gian nhận dạng trung bình: {dtw_avg_time:.2f} ms / trial")
    
    # --- VẼ CONFUSION MATRIX SIDE-BY-SIDE ---
    cm_hmm = confusion_matrix(hmm_true, hmm_pred, labels=LABELS)
    cm_dtw = confusion_matrix(dtw_true, dtw_pred, labels=LABELS)
    
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    fig.suptitle('So sánh Ma trận Nhầm lẫn (Confusion Matrix): HMM vs DTW', fontsize=14, fontweight='bold')
    
    disp_hmm = ConfusionMatrixDisplay(cm_hmm, display_labels=LABELS)
    disp_hmm.plot(cmap='Blues', ax=axes[0], colorbar=False)
    axes[0].set_title(f"Gaussian HMM (Accuracy: {hmm_acc*100:.1f}%)", fontsize=12, fontweight='bold')
    
    disp_dtw = ConfusionMatrixDisplay(cm_dtw, display_labels=LABELS)
    disp_dtw.plot(cmap='Oranges', ax=axes[1], colorbar=False)
    axes[1].set_title(f"DTW 1-NN Baseline (Accuracy: {dtw_acc*100:.1f}%)", fontsize=12, fontweight='bold')
    
    plt.tight_layout()
    cm_plot_path = 'confusion_matrices_comparison.png'
    plt.savefig(cm_plot_path, dpi=200)
    plt.close()
    print(f"\n-> Đã lưu biểu đồ so sánh Confusion Matrix tại: {cm_plot_path}")
    
    # --- BẢNG SO SÁNH ĐỐI CHIẾU ---
    print("\n" + "=" * 76)
    print("BẢNG SO SÁNH ĐỐI CHIẾU HMM (LAB 3) VÀ DTW (LAB 2)")
    print("=" * 76)
    print(f"{'Tiêu chí':<25} | {'DTW (Lab 2)':<20} | {'HMM (Lab 3)':<20}")
    print("-" * 76)
    print(f"{'Độ chính xác (Accuracy)':<25} | {dtw_acc*100:5.1f}%{'':<14} | {hmm_acc*100:5.1f}%{'':<14}")
    print(f"{'Số mẫu train/lớp':<25} | {'6 templates/lớp':<20} | {'1 mô hình (5 state)/lớp':<20}")
    print(f"{'Thời gian train':<25} | {'~0 s (Lazy learning)':<20} | {'~0.18 s (Baum-Welch)':<20}")
    print(f"{'Thời gian test/trial':<25} | {dtw_avg_time:6.2f} ms{'':<12} | {hmm_avg_time:6.2f} ms{'':<12}")
    print(f"{'Tốc độ suy luận':<25} | {'Chậm (O(K*T1*T2))':<20} | {f'Nhanh hơn ~{dtw_avg_time/hmm_avg_time:.1f}x':<20}")
    print(f"{'Top confusion pair':<25} | {'Không (100% test)':<20} | {'Không (100% test)':<20}")
    print(f"{'Khả năng giải thích':<25} | {'Warping path trực tiếp':<20} | {'Viterbi state path ngầm':<20}")
    print(f"{'Khả năng mở rộng':<25} | {'Kém (từ vựng nhỏ)':<20} | {'Rất tốt (Subword, LM)':<20}")
    print("=" * 76)

if __name__ == '__main__':
    run_step5()
