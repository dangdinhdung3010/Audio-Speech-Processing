# CSE457 - XỬ LÝ ÂM THANH VÀ TIẾNG NÓI
## BÀI THỰC HÀNH SỐ 3: NHẬN DẠNG TIẾNG NÓI NÂNG CAO VỚI HMM
**Sinh viên thực hiện:** Đặng Đình Dũng  
**Mã sinh viên:** 2351260648  
**Trường:** Đại học Thủy Lợi - Khoa Công nghệ Thông tin - Bộ môn Trí tuệ Nhân tạo  

---

## 1. Tổng quan Dự án
Dự án triển khai hoàn chỉnh một hệ thống nhận dạng tiếng nói (ASR) tách rời cho 5 từ lệnh tiếng Việt: **"mở" (`mo`)**, **"đóng" (`dong`)**, **"lên" (`len`)**, **"xuống" (`xuong`)**, **"dừng" (`dung`)** bằng mô hình Markov ẩn Gaussian (Left-to-Right Gaussian HMM). Hệ thống được so sánh toàn diện với baseline DTW của Lab 2 và mở rộng với từ điển phát âm (Lexicon) và mô hình ngôn ngữ Bigram MAP re-ranking.

### Các thành phần chính:
1. **Tiền xử lý & Trích xuất đặc trưng**: Đọc WAV 16 kHz mono, cắt silence (top_db=30), pre-emphasis (0.97), trích xuất vector đặc trưng 39 chiều ($13 \text{ MFCC} + 13 \Delta + 13 \Delta^2$), chuẩn hóa CMVN.
2. **Huấn luyện Left-to-Right Gaussian HMM**: 5 trạng thái ẩn, ma trận chuyển tiếp trái-sang-phải nghiêm ngặt ($a_{ii} = 0.7, a_{i,i+1} = 0.3$), hiệp phương sai diagonal, huấn luyện bằng thuật toán Baum-Welch (EM).
3. **Nhận dạng Maximum Likelihood & Viterbi Alignment**: Tìm từ có log-likelihood cao nhất $\arg\max_w \log P(X \mid \lambda_w)$, giải mã đường đi trạng thái tối ưu qua Viterbi và trực quan hóa thời lượng trạng thái âm học.
4. **Đối chiếu với Baseline DTW (Lab 2)**: So sánh độ chính xác, ma trận nhầm lẫn, thời gian suy luận (HMM nhanh hơn ~34 lần) và khả năng mở rộng.
5. **Mở rộng Lexicon & Bigram MAP Re-ranking**: Xây dựng `lexicon.txt` ánh xạ Word $\to$ Phones, tính xác suất Bigram với làm mịn Add-0.5, thực nghiệm MAP re-ranking với các trọng số $\lambda_{LM} \in \{0, 0.1, 0.3, 1.0\}$.
6. **Thí nghiệm có kiểm soát & Đánh giá Robustness (E1 - E6)**: Đánh giá số trạng thái ($3, 5, 7$), đặc trưng động (13 vs 39), covariance (`diag` vs `full`), kiểm tra độ bền với nhiễu và đề xuất ngưỡng từ chối $\theta = -54.0$ log-likelihood/frame để phát hiện từ lạ (Unknown/OOV).

---

## 2. Cấu trúc thư mục

```text
Lab03_2351260648_DangDinhDung/
│
├── dataset/                                # Bộ dữ liệu âm thanh 16kHz, mono, PCM 16-bit
│   ├── train/                              # 30 file huấn luyện (6 file/từ)
│   │   ├── mo/ (mo_01.wav ... mo_06.wav)
│   │   ├── dong/ (dong_01.wav ... dong_06.wav)
│   │   ├── len/ (len_01.wav ... len_06.wav)
│   │   ├── xuong/ (xuong_01.wav ... xuong_06.wav)
│   │   └── dung/ (dung_01.wav ... dung_06.wav)
│   └── test/                               # 10 file kiểm thử (2 file/từ)
│       ├── mo/ (mo_07.wav, mo_08.wav)
│       ├── dong/ (dong_07.wav, dong_08.wav)
│       ├── len/ (len_07.wav, len_08.wav)
│       ├── xuong/ (xuong_07.wav, xuong_08.wav)
│       └── dung/ (dung_07.wav, dung_08.wav)
│
├── models/                                 # Thư mục lưu các mô hình đã huấn luyện
│   └── hmm_models.pkl                      # 5 Whole-word Gaussian HMM đã serialize
│
├── lexicon.txt                             # Từ điển phát âm mini ánh xạ Word -> Phones
│
├── check_dataset.py                        # Script kiểm tra chuẩn hóa dữ liệu
├── generate_dataset.py                     # Script tạo tập âm thanh đa dạng giọng đọc
├── step2_feature_extraction.py             # Trích xuất 39-D MFCC và vẽ Heatmap
├── step3_train_hmm.py                      # Huấn luyện 5 mô hình HMM Baum-Welch
├── step4_recognize_viterbi.py              # Nhận dạng ML và phân tích Viterbi path
├── step5_eval_and_dtw.py                   # Đánh giá toàn diện và so sánh với DTW
├── step6_lexicon_bigram.py                 # Mở rộng Lexicon và Bigram Re-ranking
├── step7_experiments_robustness.py         # Thực hiện 6 thí nghiệm bắt buộc E1 - E6
│
├── Lab03.py                                # File chạy toàn bộ Pipeline từ đầu đến cuối
├── Lab03.ipynb                             # Jupyter Notebook hoàn chỉnh
│
├── heatmap_mfcc_comparison.png             # Hình ảnh so sánh Heatmap MFCC giữa các từ
├── viterbi_alignment.png                   # Đồ thị căn chỉnh trạng thái Viterbi theo thời gian
├── confusion_matrices_comparison.png       # Ma trận nhầm lẫn đối chiếu HMM vs DTW
├── score_distribution_rejection.png        # Phân bố điểm số và ngưỡng từ chối (Reject Threshold)
│
├── BaoCao_Lab03_2351260648_DangDinhDung.md   # Báo cáo thực hành chi tiết dạng Markdown
├── BaoCao_Lab03_2351260648_DangDinhDung.docx # Báo cáo thực hành hoàn chỉnh dạng Word DOCX
└── README.md                               # Tài liệu hướng dẫn sử dụng
```

---

## 3. Cài đặt môi trường

Cài đặt các thư viện cần thiết bằng pip:
```bash
pip install numpy scipy matplotlib librosa soundfile scikit-learn hmmlearn python-docx
```

---

## 4. Hướng dẫn chạy chương trình

### Cách 1: Chạy toàn bộ Pipeline tự động
Chạy script hợp nhất duy nhất:
```bash
python Lab03.py
```

### Cách 2: Chạy trên Jupyter Notebook
Mở file `Lab03.ipynb` trong Jupyter Lab / VSCode / Spyder và chọn **Run All Cells**.

### Cách 3: Chạy từng bước thực nghiệm riêng rẽ
1. **Kiểm tra dữ liệu**:
   ```bash
   python check_dataset.py
   ```
2. **Trích xuất đặc trưng và vẽ biểu đồ nhiệt (Heatmap)**:
   ```bash
   python step2_feature_extraction.py
   ```
3. **Huấn luyện 5 mô hình HMM**:
   ```bash
   python step3_train_hmm.py
   ```
4. **Nhận dạng và vẽ Viterbi State Alignment**:
   ```bash
   python step4_recognize_viterbi.py
   ```
5. **Đánh giá và so sánh đối chiếu với DTW**:
   ```bash
   python step5_eval_and_dtw.py
   ```
6. **Mở rộng Lexicon và Bigram Language Model Re-ranking**:
   ```bash
   python step6_lexicon_bigram.py
   ```
7. **Chạy các thí nghiệm E1 - E6 và phân tích ngưỡng từ chối**:
   ```bash
   python step7_experiments_robustness.py
   ```

---

## 5. Tóm tắt kết quả chính
- **Độ chính xác (Accuracy)**: HMM đạt **100.0%** (10/10 mẫu test).
- **Tốc độ suy luận**: HMM đạt **0.76 ms / trial**, nhanh hơn DTW (**25.66 ms / trial**) gấp **~34 lần**.
- **Topology HMM**: Cấu trúc Left-to-Right được bảo toàn tuyệt đối, không nhảy lùi, không skip.
- **Ngưỡng từ chối đề xuất**: $\theta = -54.0 \text{ log-likelihood / frame}$ giúp hệ thống phát hiện chính xác các từ lạ (Out-Of-Vocabulary) và tạp âm môi trường.
