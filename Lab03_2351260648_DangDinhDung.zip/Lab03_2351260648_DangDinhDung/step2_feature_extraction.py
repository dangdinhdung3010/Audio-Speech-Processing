import os
import sys
import numpy as np
import librosa
import matplotlib.pyplot as plt

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

def extract_feat(path, sr=16000):
    """
    Trích xuất đặc trưng 39 chiều: 13 MFCC + 13 Delta + 13 Delta-Delta
    kèm theo cắt silence (top_db=30), lọc tiền nhấn (coef=0.97) và chuẩn hóa CMVN.
    """
    # 1. Đọc tín hiệu âm thanh
    y, sr = librosa.load(path, sr=sr, mono=True)
    
    # 2. Cắt silence ở hai đầu
    y, _ = librosa.effects.trim(y, top_db=30)
    
    # 3. Lọc tiền nhấn pre-emphasis
    y = librosa.effects.preemphasis(y, coef=0.97)
    
    # 4. Trích xuất 13 MFCC tĩnh (cửa sổ 25ms, bước nhảy 10ms, hamming)
    mfcc = librosa.feature.mfcc(
        y=y, sr=sr, n_mfcc=13,
        n_fft=512, win_length=int(0.025 * sr),
        hop_length=int(0.010 * sr), window='hamming',
        n_mels=26, fmin=20, fmax=sr / 2
    )
    
    # 5. Tính đạo hàm bậc 1 (Delta) và bậc 2 (Delta-Delta)
    d1 = librosa.feature.delta(mfcc, order=1)
    d2 = librosa.feature.delta(mfcc, order=2)
    
    # Ghép 3 thành phần thành ma trận kích thước T x 39
    F = np.vstack([mfcc, d1, d2]).T  # T x 39
    
    # 6. Chuẩn hóa CMVN (utterance-level)
    mu = F.mean(axis=0, keepdims=True)
    sd = F.std(axis=0, keepdims=True) + 1e-8
    F_norm = (F - mu) / sd
    
    return F_norm

def run_step2():
    print("=" * 65)
    print("BƯỚC 2: TIỀN XỬ LÝ VÀ TRÍCH XUẤT ĐẶC TRƯNG 39 CHIỀU")
    print("=" * 65)
    
    # Kiểm tra kích thước của ít nhất 3 file
    sample_files = [
        ('dataset/train/mo/mo_01.wav', 'Lệnh "mở" (mo_01)'),
        ('dataset/train/dong/dong_01.wav', 'Lệnh "đóng" (dong_01)'),
        ('dataset/train/len/len_01.wav', 'Lệnh "lên" (len_01)'),
        ('dataset/train/xuong/xuong_01.wav', 'Lệnh "xuống" (xuong_01)'),
        ('dataset/train/dung/dung_01.wav', 'Lệnh "dừng" (dung_01)'),
    ]
    
    print("\n[1] Kiểm tra kích thước ma trận đặc trưng (Shape):")
    for fpath, desc in sample_files:
        feat = extract_feat(fpath)
        print(f"  - {desc:28s}: shape = {feat.shape} (T = {feat.shape[0]} frames, D = {feat.shape[1]} chiều)")
    
    # Trích xuất đặc trưng riêng lẻ để vẽ Heatmap cho 2 từ: 'mo' và 'dong'
    print("\n[2] Vẽ heatmap phân tích MFCC, Delta, Delta-Delta cho 2 từ: 'mở' và 'đóng'...")
    
    file_mo = 'dataset/train/mo/mo_01.wav'
    file_dong = 'dataset/train/dong/dong_01.wav'
    
    def extract_components(path, sr=16000):
        y, sr = librosa.load(path, sr=sr, mono=True)
        y, _ = librosa.effects.trim(y, top_db=30)
        y = librosa.effects.preemphasis(y, coef=0.97)
        mfcc = librosa.feature.mfcc(
            y=y, sr=sr, n_mfcc=13,
            n_fft=512, win_length=int(0.025 * sr),
            hop_length=int(0.010 * sr), window='hamming',
            n_mels=26, fmin=20, fmax=sr / 2
        )
        d1 = librosa.feature.delta(mfcc, order=1)
        d2 = librosa.feature.delta(mfcc, order=2)
        # Chuẩn hóa từng thành phần để trực quan hóa rõ nét
        mfcc_norm = (mfcc - mfcc.mean(axis=1, keepdims=True)) / (mfcc.std(axis=1, keepdims=True) + 1e-8)
        d1_norm = (d1 - d1.mean(axis=1, keepdims=True)) / (d1.std(axis=1, keepdims=True) + 1e-8)
        d2_norm = (d2 - d2.mean(axis=1, keepdims=True)) / (d2.std(axis=1, keepdims=True) + 1e-8)
        return mfcc_norm, d1_norm, d2_norm
    
    mfcc_mo, d1_mo, d2_mo = extract_components(file_mo)
    mfcc_dong, d1_dong, d2_dong = extract_components(file_dong)
    
    fig, axes = plt.subplots(3, 2, figsize=(14, 10))
    fig.suptitle('So sánh Heatmap Đặc trưng Âm học: Từ "mở" (Trái) vs Từ "đóng" (Phải)', fontsize=14, fontweight='bold')
    
    # Từ "mở"
    im0 = axes[0, 0].imshow(mfcc_mo, aspect='auto', origin='lower', cmap='viridis')
    axes[0, 0].set_title('Từ "mở" - 13 MFCC tĩnh')
    axes[0, 0].set_ylabel('Hệ số MFCC')
    plt.colorbar(im0, ax=axes[0, 0])
    
    im1 = axes[1, 0].imshow(d1_mo, aspect='auto', origin='lower', cmap='coolwarm')
    axes[1, 0].set_title('Từ "mở" - 13 Delta (Vận tốc phổ)')
    axes[1, 0].set_ylabel('Hệ số Delta')
    plt.colorbar(im1, ax=axes[1, 0])
    
    im2 = axes[2, 0].imshow(d2_mo, aspect='auto', origin='lower', cmap='coolwarm')
    axes[2, 0].set_title('Từ "mở" - 13 Delta-Delta (Gia tốc phổ)')
    axes[2, 0].set_xlabel('Chỉ số khung (Frame index)')
    axes[2, 0].set_ylabel('Hệ số Delta-Delta')
    plt.colorbar(im2, ax=axes[2, 0])
    
    # Từ "đóng"
    im3 = axes[0, 1].imshow(mfcc_dong, aspect='auto', origin='lower', cmap='viridis')
    axes[0, 1].set_title('Từ "đóng" - 13 MFCC tĩnh')
    plt.colorbar(im3, ax=axes[0, 1])
    
    im4 = axes[1, 1].imshow(d1_dong, aspect='auto', origin='lower', cmap='coolwarm')
    axes[1, 1].set_title('Từ "đóng" - 13 Delta (Vận tốc phổ)')
    plt.colorbar(im4, ax=axes[1, 1])
    
    im5 = axes[2, 1].imshow(d2_dong, aspect='auto', origin='lower', cmap='coolwarm')
    axes[2, 1].set_title('Từ "đóng" - 13 Delta-Delta (Gia tốc phổ)')
    axes[2, 1].set_xlabel('Chỉ số khung (Frame index)')
    plt.colorbar(im5, ax=axes[2, 1])
    
    plt.tight_layout()
    plot_path = 'heatmap_mfcc_comparison.png'
    plt.savefig(plot_path, dpi=200)
    plt.close()
    print(f"  -> Đã lưu biểu đồ nhiệt tại: {plot_path}")
    print("=" * 65)

if __name__ == '__main__':
    run_step2()
