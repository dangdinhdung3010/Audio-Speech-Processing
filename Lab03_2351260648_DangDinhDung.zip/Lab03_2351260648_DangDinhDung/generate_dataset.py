import os
import sys
import asyncio
import tempfile
import numpy as np
import soundfile as sf
import librosa
import edge_tts

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

WORDS = {
    'mo': 'mở',
    'dong': 'đóng',
    'len': 'lên',
    'xuong': 'xuống',
    'dung': 'dừng'
}

CONFIGS = {
    'train': [
        ('01', 'vi-VN-NamMinhNeural', '+0%', '+0Hz', 0.30, 0.30),
        ('02', 'vi-VN-NamMinhNeural', '-10%', '+5Hz', 0.25, 0.25),
        ('03', 'vi-VN-NamMinhNeural', '+10%', '-5Hz', 0.35, 0.35),
        ('04', 'vi-VN-HoaiMyNeural', '+0%', '+0Hz', 0.30, 0.30),
        ('05', 'vi-VN-HoaiMyNeural', '-10%', '+5Hz', 0.25, 0.25),
        ('06', 'vi-VN-NamMinhNeural', '+5%', '+10Hz', 0.40, 0.30),
    ],
    'test': [
        ('07', 'vi-VN-NamMinhNeural', '-5%', '-10Hz', 0.30, 0.30),
        ('08', 'vi-VN-HoaiMyNeural', '+10%', '-5Hz', 0.35, 0.35),
    ]
}

TARGET_SR = 16000

async def synth_word(text, voice, rate, pitch, out_path, sil_start, sil_end):
    with tempfile.NamedTemporaryFile(suffix='.mp3', delete=False) as tmp:
        tmp_name = tmp.name

    try:
        communicate = edge_tts.Communicate(text, voice=voice, rate=rate, pitch=pitch)
        await communicate.save(tmp_name)

        # Load at 16000 Hz mono
        y, sr = librosa.load(tmp_name, sr=TARGET_SR, mono=True)
        # Trim silence from raw TTS
        y_trimmed, _ = librosa.effects.trim(y, top_db=25)
        if len(y_trimmed) == 0:
            y_trimmed = y

        # Peak normalize
        max_val = np.max(np.abs(y_trimmed))
        if max_val > 0:
            y_trimmed = 0.9 * (y_trimmed / max_val)

        # Add silence padding 0.2 - 0.5s
        sil_head = np.zeros(int(TARGET_SR * sil_start), dtype=np.float32)
        sil_tail = np.zeros(int(TARGET_SR * sil_end), dtype=np.float32)
        y_final = np.concatenate([sil_head, y_trimmed, sil_tail])

        # Write as 16-bit PCM WAV
        os.makedirs(os.path.dirname(out_path), exist_ok=True)
        sf.write(out_path, y_final, TARGET_SR, subtype='PCM_16')
    finally:
        if os.path.exists(tmp_name):
            try:
                os.remove(tmp_name)
            except Exception:
                pass

async def main():
    print("=" * 65)
    print("BẮT ĐẦU TỰ ĐỘNG KHỞI TẠO TẬP DỮ LIỆU LAB 3 (5 TỪ LỆNH TIẾNG VIỆT)")
    print("Định dạng: WAV mono, Fs = 16000 Hz, 16-bit PCM, silence 0.25 - 0.4s")
    print("=" * 65)

    total_created = 0
    for split, configs in CONFIGS.items():
        for label, text in WORDS.items():
            for idx, voice, rate, pitch, sil_start, sil_end in configs:
                fname = f"{label}_{idx}.wav"
                out_path = os.path.join("dataset", split, label, fname)
                print(f"[Tạo] {split:5s} | {label:5s} ('{text}') -> {fname:12s} ({voice.split('-')[2][:7]}, rate={rate}, pitch={pitch})")
                await synth_word(text, voice, rate, pitch, out_path, sil_start, sil_end)
                total_created += 1

    print("\n" + "=" * 65)
    print(f"Đã tạo thành công {total_created} file âm thanh chất lượng cao!")
    print("=" * 65)

if __name__ == '__main__':
    asyncio.run(main())
