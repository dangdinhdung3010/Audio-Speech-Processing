# BÁO CÁO THỰC HÀNH LAB 3: XỬ LÝ ÂM THANH VÀ TIẾNG NÓI (CSE457)
## ĐỀ TÀI: NHẬN DẠNG TIẾNG NÓI NÂNG CAO VỚI HMM
**Sinh viên thực hiện:** Đặng Đình Dũng  
**Mã sinh viên:** 2351260648  
**Lớp / Chuyên ngành:** Trí tuệ Nhân tạo và Khoa học Dữ liệu  
**Trường:** Đại học Thủy Lợi — Khoa Công nghệ Thông tin  
**Giảng viên hướng dẫn:** Bộ môn Trí tuệ Nhân tạo  

---

## 1. Thiết kế Hệ thống và Cấu hình Tham số

### 1.1. Kiến trúc Pipeline Nhận dạng
Hệ thống nhận dạng tiếng nói (ASR) tách rời cho 5 từ lệnh tiếng Việt: **"mở"**, **"đóng"**, **"lên"**, **"xuống"**, **"dừng"** được thiết kế theo quy trình xác suất chuẩn:
$$\text{Speech Waveform} \longrightarrow \text{MFCC} + \Delta + \Delta^2 \longrightarrow \text{Whole-Word HMMs} \longrightarrow \text{Acoustic Likelihood} \longrightarrow \text{Lexicon + Language Model} \longrightarrow \hat{W}$$

```
                KIẾN TRÚC TỔNG THỂ HỆ THỐNG LAB 3
+---------------+     +-----------------------+     +-------------------------+
| Sóng âm thanh | --> | 39-D MFCC + Delta     | --> | 5 Whole-Word HMMs       |
| (16kHz, mono) |     | (Trim, Pre-emp, CMVN) |     | (Left-to-Right, 5-state)|
+---------------+     +-----------------------+     +-------------------------+
                                                                 |
                                                                 v
+------------------+     +-----------------------+     +-------------------------+
| Từ lệnh dự đoán  | <-- | MAP Re-ranking        | <-- | Điểm Log-Likelihood     |
| (hoặc 'UNKNOWN') |     | (Score + lambda*LM)   |     | log P(X | lambda_w)     |
+------------------+     +-----------------------+     +-------------------------+
```

### 1.2. Bảng Cấu hình Tham số Chi tiết
| Khối chức năng | Tham số | Giá trị | Cơ sở lý thuyết và mục đích |
| :--- | :--- | :--- | :--- |
| **Âm thanh đầu vào** | Tần số lấy mẫu ($F_s$) | 16,000 Hz | Chuẩn âm học nhận dạng giọng nói, đáp ứng định lý Nyquist cho dải nghe $0–8\text{ kHz}$. |
| | Kênh / Định dạng | Mono / 16-bit PCM | Chuẩn hóa đơn kênh và bảo toàn dải động của áp suất âm thanh. |
| **Tiền xử lý** | Cắt khoảng lặng | `top_db = 30` | Loại bỏ các đoạn tĩnh lặng đầu/cuối, tránh lãng phí frame cho silence. |
| | Lọc tiền nhấn | $\alpha = 0.97$ | Bù đắp hiện tượng suy giảm $6\text{ dB/octave}$ ở dải tần số cao do bức xạ môi. |
| **Trích xuất MFCC** | Khung / Bước nhảy | 25 ms / 10 ms | Thỏa mãn tính tựa dừng (quasi-stationary) trong khung ngắn và chồng lấn $60\%$. |
| | Cửa sổ phân tích | Hamming | Giảm hiện tượng rò rỉ phổ (spectral leakage) tại biên khung. |
| | NFFT / Dải Mel | 512 / 26 bộ lọc | Độ phân giải tần số phù hợp mô phỏng đặc tính phi tuyến của ốc tai người. |
| | Số hệ số tĩnh | 13 MFCC | Nén bao phổ âm thanh ngắn hạn qua biến đổi DCT. |
| | Đặc trưng động | $13 \Delta + 13 \Delta^2$ | Đạo hàm bậc 1 (vận tốc) và bậc 2 (gia tốc) khắc phục giả thiết quan sát độc lập. |
| | Chuẩn hóa đặc trưng | Utterance CMVN | Trừ mean, chia std trên từng file để loại bỏ méo kênh truyền và micro. |
| **Cấu trúc HMM** | Số trạng thái ($N$) | 5 trạng thái | Mô tả các chặng âm học: Onset $\to$ Transition $\to$ Nucleus $\to$ Coda $\to$ Offset. |
| | Topology | Left-to-Right | Chỉ cho phép self-loop ($a_{ii}=0.7$) và tiến một bước ($a_{i,i+1}=0.3$), $a_{NN}=1.0$. |
| | Phân bố phát xạ | 1 Gaussian/state | Ước lượng vector trung bình $\mu_i \in \mathbb{R}^{39}$ và ma trận hiệp phương sai. |
| | Kiểu hiệp phương sai | Diagonal (`diag`) | Chỉ giữ 39 giá trị phương sai/state, chống overfitting trên tập mẫu nhỏ. |
| **Huấn luyện & Giải mã**| Thuật toán học | Baum-Welch (EM) | Cực đại hóa xác suất hợp lý cục bộ $P(X \mid \lambda)$ với điều kiện dừng $\text{tol}=10^{-3}$. |
| | Giải mã nhận dạng | Maximum Likelihood | $\hat{w} = \arg\max_w \log P(X \mid \lambda_w)$ kết hợp ngưỡng từ chối $\theta$. |
| | Giải mã căn chỉnh | Viterbi algorithm | Tìm chuỗi trạng thái ẩn $Q^* = (q_1, \dots, q_T)$ có xác suất cực đại. |

---

## 2. Toàn bộ Kết quả Thực nghiệm và Biểu đồ Trực quan hóa

### 2.1. Biểu đồ nhiệt (Heatmap) Đặc trưng Âm học: Từ "mở" vs Từ "đóng"
Hình ảnh thực nghiệm: `heatmap_mfcc_comparison.png`

```
+---------------------------------------------------------------------------------------------------+
|               So sánh Heatmap Đặc trưng Âm học: Từ "mở" (Trái) vs Từ "đóng" (Phải)                |
|                                                                                                   |
|  [Hàng 1]: 13 MFCC tĩnh      |  "mở" m-vowel mượt mà       |  "đóng" phân đoạn rõ: d -> o -> ng   |
|  [Hàng 2]: 13 Delta (Vận tốc)|  Biến thiên đều, êm dịu     |  Đột biến mạnh tại onset và coda     |
|  [Hàng 3]: 13 Delta2(Gia tốc)|  Tập trung ở ranh giới âm   |  Nhiều cực trị gia tốc ở chuyển âm   |
+---------------------------------------------------------------------------------------------------+
```

#### Phân tích so sánh chi tiết:
1. **13 MFCC tĩnh**:
   - **Từ "mở"**: Bắt đầu bằng âm mũi môi /m/ với năng lượng dồn tại các dải tần thấp (hệ số MFCC 1–3), tiếp nối bằng nguyên âm mở /əː/ với bề mặt phổ trải đều và mượt mà.
   - **Từ "đóng"**: Cấu trúc âm phức hợp rõ rệt: phụ âm đầu tắc-hữu thanh /d/ (năng lượng đột ngột), chuyển sang nguyên âm giữa /ɔ/, kết thúc bằng phụ âm mũi ngạc mềm /ŋ/. Năng lượng phổ biến thiên mạnh qua 3 chặng thời gian.
2. **$\Delta$ và $\Delta^2$ (Đặc trưng động)**:
   - Các hệ số Delta của từ "đóng" có các dải màu tương phản cực đại (vận tốc phổ thay đổi nhanh) tại thời điểm bộc phát phụ âm đầu và khép phụ âm cuối.
   - Các đỉnh của Delta-Delta đánh dấu chính xác ranh giới chuyển đổi trạng thái âm vị học (phoneme transitions), cung cấp bằng chứng động học vô giá mà các hệ số MFCC tĩnh không thể hiện được.

---

### 2.2. Căn chỉnh Chuỗi Trạng thái Viterbi (Viterbi Alignment)
Hình ảnh thực nghiệm: `viterbi_alignment.png`

```
        Đồ thị Căn chỉnh Trạng thái Viterbi (Viterbi State Alignment)
State 4 |                                                    
State 3 |                       +-------            +--------
State 2 |             +---  +---+              +----+        
State 1 |         +---+     |                  |             
State 0 +---------+         +------------------+             
        0        15   30   45 (Frame index: 10ms/frame)
         mo_07.wav ("mở")     dong_07.wav ("đóng")    len_07.wav ("lên")
```

#### Bảng thống kê thời lượng các trạng thái (Duration Analysis):
| Mẫu âm thanh | Trạng thái (State) | Số frame | Thời lượng (ms) | Tỷ lệ (%) | Phân đoạn âm học tương ứng |
| :--- | :---: | :---: | :---: | :---: | :--- |
| **`mo_07.wav` ("mở")** | State 0 | 16 frames | 160 ms | 35.6% | Phụ âm mũi khởi đầu /m/ |
| ($T = 45\text{ frames}$) | State 1 | 23 frames | 230 ms | 51.1% | Nguyên âm chính ngân dài /əː/ |
| | State 2 | 6 frames | 60 ms | 13.3% | Đuôi suy giảm năng lượng khi kết thúc phát âm |
| **`dong_07.wav` ("đóng")**| State 0 | 7 frames | 70 ms | 16.7% | Pha ngậm và bộc phát của phụ âm tắc /d/ |
| ($T = 42\text{ frames}$) | State 1 | 13 frames | 130 ms | 31.0% | Đoạn chuyển tiếp formant sang nguyên âm |
| | State 2 | 16 frames | 160 ms | 38.1% | Nguyên âm hạt nhân ổn định /ɔ/ |
| | State 3 | 6 frames | 60 ms | 14.3% | Phụ âm mũi khép ngạc mềm /ŋ/ |
| **`len_07.wav` ("lên")** | State 0 | 8 frames | 80 ms | 19.0% | Phụ âm bên chân răng /l/ |
| ($T = 42\text{ frames}$) | State 1 | 5 frames | 50 ms | 11.9% | Chuyển tiếp formant nhanh |
| | State 2 | 10 frames | 100 ms | 23.8% | Bắt đầu nguyên âm nửa mở /e/ |
| | State 3 | 19 frames | 190 ms | 45.2% | Nguyên âm ổn định và phụ âm mũi cuối /n/ |

#### Nhận xét định lượng:
- Chuỗi trạng thái hoàn toàn đơn điệu không giảm ($q_t \ge q_{t-1}$), chứng minh thuật toán Viterbi tìm được đường đi tuân thủ $100\%$ cấu trúc Left-to-Right.
- **Thời lượng dừng tại mỗi trạng thái**: Trạng thái có số khung lớn nhất luôn rơi vào pha phát âm nguyên âm hạt nhân (vowel nucleus) do đây là vùng có phổ tựa dừng và năng lượng bền vững nhất.

---

### 2.3. Bảng điểm Log-Likelihood và Phân tích Quyết định Nhận dạng
Bảng điểm âm học của các mẫu kiểm thử test đối với toàn bộ 5 mô hình HMM:

| Mẫu kiểm thử | Nhãn gốc | Score `mo` | Score `dong` | Score `len` | Score `xuong` | Score `dung` | Dự đoán | Khoảng cách $\Delta_{\text{top1-top2}}$ |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| `mo_07.wav` | **mo** | **-2307.14** | -2979.95 | -2813.77 | -3442.01 | -3218.54 | **mo** | $+506.63$ |
| `mo_08.wav` | **mo** | **-2289.45** | -2890.12 | -2754.30 | -3310.80 | -3105.42 | **mo** | $+464.85$ |
| `dong_07.wav`| **dong** | -2701.02 | **-2012.94** | -2799.15 | -2657.79 | -2880.83 | **dong** | $+644.86$ |
| `dong_08.wav`| **dong** | -2645.10 | **-1980.25** | -2710.40 | -2590.15 | -2812.60 | **dong** | $+609.90$ |
| `len_07.wav` | **len** | -2710.92 | -2784.25 | **-1971.36** | -3270.79 | -2381.34 | **len** | $+409.97$ |
| `len_08.wav` | **len** | -2680.15 | -2720.50 | **-1950.12** | -3190.40 | -2340.85 | **len** | $+390.73$ |
| `xuong_07.wav`| **xuong** | -2517.26 | -2461.24 | -2916.64 | **-1690.58** | -2846.23 | **xuong**| $+770.67$ |
| `xuong_08.wav`| **xuong** | -2480.30 | -2410.80 | -2850.10 | **-1655.40** | -2790.50 | **xuong**| $+755.40$ |
| `dung_07.wav` | **dung** | -2710.92 | -2717.05 | -2681.96 | -3341.47 | **-1932.24** | **dung** | $+749.72$ |
| `dung_08.wav` | **dung** | -2695.40 | -2680.10 | -2620.30 | -3290.15 | **-1895.60** | **dung** | $+724.70$ |

> **Phân tích độ tin cậy**: Khoảng cách $\Delta = \text{Score}_{\text{top1}} - \text{Score}_{\text{top2}}$ dao động từ $+390$ đến $+770$ log-points. Tỉ lệ xác suất Bayes $P(\text{top1})/P(\text{top2}) = e^{\Delta} > 10^{169}$, khẳng định mô hình tách biệt ranh giới quyết định rất an toàn, không có sự nhập nhằng giữa các lớp.

---

### 2.4. So sánh Đối chiếu Toàn diện HMM (Lab 3) và DTW (Lab 2)
Hình ảnh thực nghiệm: `confusion_matrices_comparison.png`

| Tiêu chí so sánh | DTW Baseline (Lab 2) | Gaussian HMM (Lab 3) | Nhận xét bản chất kỹ thuật |
| :--- | :--- | :--- | :--- |
| **Độ chính xác (Accuracy)** | **100.0%** (10/10) | **100.0%** (10/10) | Cả hai đạt hiệu năng tuyệt đối trên tập 5 lệnh tách rời. |
| **Số mẫu train / lớp** | 6 templates/lớp (lưu 30 mẫu) | 1 mô hình tham số (5 states) | HMM nén dữ liệu vào ma trận xác suất; DTW lưu toàn bộ file. |
| **Thời gian huấn luyện** | $\approx 0\text{ s}$ (Lazy learning) | $\approx 0.18\text{ s}$ (Baum-Welch EM) | Chi phí huấn luyện ban đầu của HMM rất nhỏ và chỉ thực hiện 1 lần. |
| **Thời gian suy luận (Test)** | **25.66 ms / mẫu** | **0.76 ms / mẫu** | **HMM nhanh hơn DTW gấp ~34 lần!** |
| **Độ phức tạp suy luận** | $\mathcal{O}(K \cdot N_{\text{train}} \cdot T_1 T_2)$ | $\mathcal{O}(C \cdot N_{\text{states}}^2 T)$ | DTW nghẽn cổ chai khi tăng dữ liệu; HMM độc lập với số mẫu train. |
| **Top confusion pair** | Không có (100% đúng) | Không có (100% đúng) | Cả 2 hệ thống đều phân định chính xác. |
| **Căn chỉnh thời gian** | Warping path trực tiếp $(i_k, j_k)$| Viterbi state path ẩn $q_t$ | Viterbi gắn trực tiếp với phân đoạn âm vị học. |
| **Khả năng mở rộng (Scale)** | Kém (Chỉ cho từ đơn nhỏ) | **Rất tốt (Subword, N-gram, LM)** | HMM là nền tảng cốt lõi của ASR hiện đại. |

---

### 2.5. Kết quả 6 Thí nghiệm Bắt buộc (E1 – E6)

#### Thí nghiệm E1: Thay đổi số trạng thái $n\_states \in \{3, 5, 7\}$
- **$n\_states = 3$**: LL/frame = $-48.92$, Accuracy = $100.0\%$. Mô hình tinh gọn nhưng điểm likelihood thấp hơn vì chỉ gộp chung thành 3 pha thô.
- **$n\_states = 5$ (Chuẩn)**: LL/frame = **$-42.65$**, Accuracy = **$100.0\%$**. Điểm likelihood tăng vượt bậc ($+6.3$ điểm/frame), mô tả chính xác quá trình chuyển tiếp ngữ âm.
- **$n\_states = 7$**: LL/frame = $-42.27$, Accuracy = $100.0\%$. Likelihood chỉ tăng nhẹ ($0.38$ điểm) nhưng số frame cho mỗi state bị ép xuống quá ngắn (~5 frame/state), dễ gây over-segmentation.

#### Thí nghiệm E2: 13 MFCC tĩnh vs 39 MFCC động
- Thêm $\Delta$ và $\Delta^2$ giúp mô hình hóa được tốc độ và gia tốc biến đổi của dải formant, loại bỏ giả định các frame độc lập với nhau, giúp nhận dạng bền vững hơn trong các môi trường có nhiễu.

#### Thí nghiệm E3: Kiểu hiệp phương sai `diag` vs `full`
- **`diag` (39 tham số/state)**: Train LL = $-42.65$, Test Accuracy = **$100.0\%$**. Hoạt động cực kỳ ổn định.
- **`full` (780 tham số/state)**: Train LL = $+18.50$, Test Accuracy = **$20.0\%$**!
- **Giải thích**: Do $D=39$, ma trận đầy đủ có tới 780 tham số tự do. Với chỉ 6 file train/lớp, số frame không đủ để hội tụ, dẫn đến ma trận kì dị và hiện tượng **quá khớp (overfitting) thảm họa**.

#### Thí nghiệm E4: Khi nào DTW tốt hơn HMM và ngược lại?
- DTW tốt hơn khi chỉ có $1–2$ mẫu huấn luyện (one-shot learning).
- HMM tốt hơn khi triển khai thực tế cần tốc độ cao, khả năng chống nhiễu và mở rộng từ vựng lớn.

#### Thí nghiệm E5 & Yêu cầu H: Độ bền vững và Thiết lập Ngưỡng từ chối (Reject Threshold)
Hình ảnh thực nghiệm: `score_distribution_rejection.png`
- **Thử nghiệm nhiễu**: Độ chính xác vẫn duy trì $100\%$ khi có nhiễu trắng nhẹ đến $\sigma = 0.30$ nhờ chuẩn hóa CMVN.
- **Phân bố điểm số**:
  - Mẫu đúng lớp: Trung bình **$-48.26$** (Min = $-51.27$).
  - Mẫu sai lớp: Trung bình **$-68.32$** (Max = $-56.70$).
  - Mẫu từ lạ / Tạp âm (Unknown): Trung bình **$-81.27$** (Max = $-62.54$).
- **Đề xuất Ngưỡng từ chối**:
  $$\theta_{\text{reject}} = -54.0 \text{ log-likelihood / frame}$$
  Quy tắc: Nếu $\max_w \left[ \frac{\log P(X \mid \lambda_w)}{T} \right] < -54.0 \implies$ Trả về **"UNKNOWN"**.

#### Thí nghiệm E6: Vai trò của Trọng số Mô hình Ngôn ngữ $\lambda_{LM}$
- $\lambda_{LM} = 0.0$: Thuần âm học. Dễ bị sai khi âm thanh bị nhiễu.
- $\lambda_{LM} \in [0.1, 0.3]$: Cân bằng tối ưu. Sửa lỗi chính xác khi hai ứng viên âm học cạnh tranh sít sao.
- $\lambda_{LM} \ge 5.0 - 20.0$: Hiện tượng **áp đảo (Over-dominance)**. Hệ thống bị định kiến ngôn ngữ chi phối và phớt lờ âm thanh thực tế của người nói.

---

## 3. Trả lời Đầy đủ 10 Câu hỏi Lý thuyết và Phân tích (Mục 6.1)

### Câu 1: Forward và Viterbi khác nhau ở phép toán nào và trả lời hai câu hỏi khác nhau ra sao?
- **Khác nhau ở phép toán cốt lõi**:
  - Thuật toán **Forward** sử dụng **phép cộng (Summation)**: $\alpha_t(j) = b_j(x_t) \sum_i \alpha_{t-1}(i) a_{ij}$.
  - Thuật toán **Viterbi** sử dụng **phép lấy cực đại (Maximization)**: $\delta_t(j) = b_j(x_t) \max_i [\delta_{t-1}(i) a_{ij}]$.
- **Trả lời hai câu hỏi khác nhau**:
  - **Forward** trả lời câu hỏi: *"Tổng xác suất sinh ra chuỗi quan sát $X$ trên toàn bộ tất cả các đường đi trạng thái khả dĩ của mô hình $\lambda$ là bao nhiêu?"* ($P(X \mid \lambda)$).
  - **Viterbi** trả lời câu hỏi: *"Đường đi trạng thái đơn lẻ cụ thể nào $Q^* = (q_1^*, \dots, q_T^*)$ là tối ưu nhất (có xác suất cao nhất) đã sinh ra chuỗi quan sát $X$?"* ($\arg\max_Q P(X, Q \mid \lambda)$).

---

### Câu 2: Giải thích $\gamma_t(i)$ và $\xi_t(i,j)$ bằng ngôn ngữ “trách nhiệm” (responsibility) trong EM?
Trong khuôn khổ thuật toán cực đại hóa kỳ vọng (Expectation-Maximization - EM):
- **$\gamma_t(i) = P(q_t = i \mid X, \lambda)$**: Đại diện cho **mức độ chịu trách nhiệm của trạng thái $i$** đối với việc sinh ra vector quan sát $x_t$ tại thời điểm $t$. Trong bước M (Maximization), $\gamma_t(i)$ đóng vai trò là trọng số để tính trung bình có trọng số cập nhật vector trung bình $\mu_i$ và ma trận hiệp phương sai $\Sigma_i$.
- **$\xi_t(i,j) = P(q_t = i, q_{t+1} = j \mid X, \lambda)$**: Đại diện cho **mức độ chịu trách nhiệm của bước chuyển tiếp từ trạng thái $i$ sang trạng thái $j$** tại thời điểm chuyển giao từ $t$ sang $t+1$. Tổng $\sum_t \xi_t(i,j)$ thể hiện số lần kỳ vọng xảy ra chuyển tiếp $i \to j$, được dùng để cập nhật xác suất chuyển tiếp $a_{ij}$.

---

### Câu 3: Tại sao Baum-Welch có thể hội tụ đến nghiệm xấu? Liệt kê ít nhất ba nguyên nhân thực nghiệm.
Thuật toán Baum-Welch bản chất là thuật toán leo đồi (Hill Climbing) dựa trên EM, chỉ đảm bảo hội tụ về **cực đại cục bộ (Local Optima)** chứ không đảm bảo cực đại toàn cục:
1. **Khởi tạo tham số ban đầu nghèo nàn (Bad Initialization)**: Nếu các vector trung bình ban đầu bị khởi tạo ngẫu nhiên mà không phân bổ dọc theo trục thời gian, các trạng thái sau sẽ không nhận được frame nào ($\gamma_t(i) \approx 0$).
2. **Thiếu hụt dữ liệu huấn luyện (Data Scarcity)**: Số lượng mẫu phát âm quá ít không đủ để bao quát không gian âm học 39 chiều, khiến một số trạng thái bị "đói dữ liệu", dẫn đến phương sai suy biến về 0.
3. **Cấu hình số trạng thái không phù hợp (Model Mis-specification)**: Đặt số trạng thái quá lớn ($N \ge 7$) so với từ ngắn gây over-fitting và bẫy vào các điểm dừng cục bộ không mang ý nghĩa ngữ âm.

---

### Câu 4: Tại sao diagonal covariance thường được ưu tiên khi dữ liệu nhỏ và feature dimension cao?
- **Tiết kiệm tham số**: Với vector $D = 39$ chiều:
  - Ma trận `full` cần ước lượng $\frac{D(D+1)}{2} = \frac{39 \times 40}{2} = 780$ tham số cho mỗi trạng thái.
  - Ma trận `diag` chỉ cần đúng $D = 39$ tham số phương sai trên đường chéo chính (giảm **20 lần**).
- **Tránh suy biến ma trận (Singularity)**: Với ít dữ liệu, ma trận hiệp phương sai đầy đủ rất dễ bị suy biến (định thức $| \Sigma | \to 0$), gây lỗi chia cho $0$ hoặc log của số âm trong hàm mật độ Gauss.
- **Đặc trưng MFCC đã được giải tương quan**: Phép biến đổi Cosine rời rạc (DCT) trong quy trình trích xuất MFCC đã trực giao hóa và giải tương quan cao độ giữa các chiều, khiến giả định các chiều độc lập với nhau (hiệp phương sai ngoài đường chéo bằng 0) là hoàn toàn hợp lý về mặt toán học.

---

### Câu 5: Vì sao delta features hữu ích dù HMM đã mô hình hóa chuỗi theo thời gian?
- HMM chuẩn có **giả thiết quan sát độc lập (Output Independence Assumption)**: $P(x_t \mid q_t, x_{t-1}, \dots) = P(x_t \mid q_t)$, tức giả định frame hiện tại chỉ phụ thuộc trạng thái ẩn mà hoàn toàn độc lập với các frame xung quanh.
- Trên thực tế, bộ máy phát âm của con người có quán tính cơ học liên tục; các formant di chuyển mượt mà chứ không nhảy cóc.
- Việc tính đạo hàm bậc 1 ($\Delta$) và bậc 2 ($\Delta^2$) đã **"nhúng trực tiếp" thông tin động học về vận tốc và gia tốc biến thiên phổ** vào bên trong vector đặc trưng của từng frame đơn lẻ, bù đắp hoàn hảo cho điểm yếu lý thuyết của giả thiết độc lập.

---

### Câu 6: Whole-word HMM không cần lexicon trong trường hợp nào? Khi nào lexicon trở thành bắt buộc?
- **Không cần Lexicon**: Khi xây dựng hệ thống nhận dạng tập từ vựng đóng, nhỏ và cô lập (ví dụ: 5 lệnh điều khiển hoặc các chữ số $0–9$). Ở đây, mỗi mô hình HMM đại diện trực tiếp cho toàn bộ một từ (Whole-word HMM), nhãn từ được gắn thẳng với mô hình mà không cần phân tích thành các âm vị.
- **Trở thành bắt buộc**: Khi mở rộng hệ thống sang **từ vựng lớn (Large Vocabulary)** hoặc **nhận dạng tiếng nói liên tục (Continuous Speech)**. Khi đó, việc thu âm hàng chục ngàn từ riêng rẽ là bất khả thi. Hệ thống bắt buộc phải dùng các mô hình âm vị nhỏ (Subword/Phone HMM) và dùng **Lexicon** làm cầu nối ánh xạ chuỗi âm vị thành từ có nghĩa.

---

### Câu 7: Nếu test utterance dài hơn do nói chậm, self-loop của HMM giúp gì?
- Xác suất tự lặp (Self-loop) $a_{ii} = P(q_t = i \mid q_{t-1} = i)$ trong ma trận chuyển trạng thái cho phép mô hình HMM **lưu lại ở cùng một trạng thái âm học trong nhiều khung liên tiếp**.
- Về mặt toán học, thời gian dừng tại một trạng thái tuân theo phân bố hình học có kỳ vọng $\mathbb{E}[d_i] = \frac{1}{1 - a_{ii}}$.
- Khi người nói phát âm chậm hoặc ngân dài nguyên âm, số frame tăng lên. Cơ chế self-loop tự động hấp thụ các frame dư thừa này tại các trạng thái ổn định mà không bắt buộc mô hình phải nhảy vội sang trạng thái kế tiếp, giúp mô hình co giãn thời gian ngầm định cực kỳ tự nhiên.

---

### Câu 8: Với cùng một utterance, có cần chia log-likelihood cho T để chọn model tốt nhất không? Tại sao?
- **Không cần thiết khi phân loại thông thường**: Khi so sánh các mô hình trên **cùng một utterance**, độ dài $T$ (số frame) của chuỗi quan sát $X$ đối với tất cả các mô hình $\lambda_w$ là **hoàn toàn giống nhau**. Do hàm $\frac{1}{T}$ là một hằng số dương, phép chia không làm thay đổi thứ tự xếp hạng:
$$\arg\max_w \log P(X \mid \lambda_w) = \arg\max_w \left[ \frac{\log P(X \mid \lambda_w)}{T} \right]$$
- **Tuy nhiên, việc chia cho $T$ là bắt buộc khi**:
  1. Đặt **ngưỡng từ chối (Reject Threshold)** để phát hiện từ lạ ngoài từ vựng.
  2. So sánh độ tin cậy giữa các phát âm có độ dài khác nhau.
  3. Kết hợp với điểm số mô hình ngôn ngữ trong MAP re-ranking ($\text{Score} = \frac{\text{Acoustic}}{T} + \lambda_{LM} \log P_{LM}$).

---

### Câu 9: So sánh warping path của DTW với state path của Viterbi.
| Khía cạnh | Warping Path (DTW) | State Path (Viterbi) |
| :--- | :--- | :--- |
| **Bản chất đường đi** | Chuỗi các cặp chỉ số khung $(i_k, j_k)$ giữa 2 chuỗi âm thanh cụ thể. | Chuỗi các trạng thái thống kê ẩn $Q^* = (q_1, \dots, q_T)$ của mô hình. |
| **Không gian ánh xạ** | Ánh xạ trực tiếp $1-1$, $1-N$, hoặc $N-1$ giữa các frame của 2 file. | Ánh xạ từng frame vào một phân bố xác suất Gaussian trong không gian trạng thái. |
| **Ý nghĩa âm học** | Chỉ ra frame nào của file test tương ứng với frame nào của file template. | Chỉ ra frame nào thuộc về đoạn âm học nào (phụ âm đầu, formant chuyển tiếp, hay nguyên âm). |
| **Cơ chế tối ưu** | Cực tiểu hóa tổng khoảng cách Euclidean tích lũy. | Cực đại hóa tích xác suất chuyển tiếp và xác suất phát xạ Gauss. |

---

### Câu 10: Nếu hệ thống gặp một từ ngoài vocabulary, tại sao argmax vẫn bắt buộc chọn một lớp? Hãy đề xuất reject criterion.
- **Tại sao argmax vẫn bắt buộc chọn?**
  Hàm toán học $\hat{w} = \arg\max_{w \in \mathcal{V}} P(X \mid \lambda_w)$ chỉ thực hiện phép so sánh tương đối giữa các phần tử trong tập hữu hạn $\mathcal{V}$. Ngay cả khi từ phát âm hoàn toàn xa lạ hoặc chỉ là tiếng ho/tiếng ồn, tất cả các mô hình đều cho điểm rất thấp (ví dụ $-4000$), nhưng argmax vẫn luôn trả về từ có điểm "ít xấu nhất", dẫn đến dự đoán sai mù quáng.
- **Đề xuất Tiêu chí Từ chối (Reject Criterion)**:
  Sử dụng chuẩn hóa log-likelihood trên mỗi frame kết hợp kiểm tra độ tự tin:
  1. **Ngưỡng điểm tuyệt đối trên mỗi frame**:
     $$\bar{s}(X) = \frac{\max_{w \in \mathcal{V}} \log P(X \mid \lambda_w)}{T}$$
     Nếu $\bar{s}(X) < \theta_{\text{abs}}$ (với $\theta_{\text{abs}} = -54.0\text{ dB/frame}$), từ chối nhận dạng và trả về **"UNKNOWN"**.
  2. **Ngưỡng khoảng cách tương đối (Margin / Confidence Gap)**:
     $$\Delta = \bar{s}_{\text{top1}} - \bar{s}_{\text{top2}}$$
     Nếu $\Delta < \theta_{\text{margin}}$ (ví dụ $\theta_{\text{margin}} = 2.0\text{ điểm/frame}$), cảnh báo hệ thống không đủ tự tin để phân định và yêu cầu người dùng phát âm lại.

---

## 4. Kết luận
Bài thực hành số 3 đã hoàn thành xuất sắc toàn bộ các mục tiêu đặt ra:
1. Xây dựng trọn vẹn pipeline nhận dạng 5 từ lệnh tiếng Việt bằng Left-to-Right Gaussian HMM với độ chính xác đạt tuyệt đối **100%**.
2. Chứng minh thực nghiệm ưu thế vượt trội của HMM so với DTW về tốc độ suy luận (nhanh hơn ~34 lần) và khả năng nén tri thức.
3. Làm chủ cơ chế giải mã căn chỉnh Viterbi, kết hợp Lexicon và mô hình ngôn ngữ Bigram MAP re-ranking.
4. Đánh giá tính bền bỉ và thiết lập thành công ngưỡng từ chối $\theta = -54.0$ cho bài toán nhận dạng thực tế.
