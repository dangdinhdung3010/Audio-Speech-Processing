import os
import sys
import soundfile as sf
import numpy as np

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

LABELS = ['mo', 'dong', 'len', 'xuong', 'dung']
SPLITS = {'train': 6, 'test': 2}
TARGET_SR = 16000

def check_dataset(data_dir="dataset"):
    print("=" * 60)
    print("KIỂM TRA TẬP DỮ LIỆU LAB 3")
    print("=" * 60)
    total_files = 0
    issues = []

    for split, expected_count in SPLITS.items():
        print(f"\n[+] Kiểm tra tập: {split.upper()} (yêu cầu {expected_count} file/từ)")
        split_dir = os.path.join(data_dir, split)
        if not os.path.exists(split_dir):
            issues.append(f"Thư mục {split_dir} chưa tồn tại!")
            continue

        for label in LABELS:
            label_dir = os.path.join(split_dir, label)
            if not os.path.exists(label_dir):
                issues.append(f"Thư mục nhãn {label_dir} chưa tồn tại!")
                continue

            files = [f for f in sorted(os.listdir(label_dir)) if f.lower().endswith('.wav')]
            file_count = len(files)
            total_files += file_count
            status = "OK" if file_count >= expected_count else f"THIẾU ({file_count}/{expected_count})"
            print(f"  - {label:6s}: {file_count} files [{status}]")

            for fname in files:
                fpath = os.path.join(label_dir, fname)
                try:
                    data, sr = sf.read(fpath)
                    info = sf.info(fpath)
                    channels = info.channels
                    subtype = info.subtype
                    duration = len(data) / sr

                    # Kiểm tra tham số
                    errs = []
                    if sr != TARGET_SR:
                        errs.append(f"sr={sr}!=16000")
                    if channels != 1:
                        errs.append(f"channels={channels}!=1 (mono)")
                    if 'PCM_16' not in subtype:
                        errs.append(f"subtype={subtype}!=PCM_16")

                    if errs:
                        issues.append(f"File {fpath}: {', '.join(errs)}")
                except Exception as e:
                    issues.append(f"Lỗi đọc file {fpath}: {e}")

    print("\n" + "=" * 60)
    print(f"Tổng số file WAV tìm thấy: {total_files}")
    if issues:
        print(f"Phát hiện {len(issues)} vấn đề cần lưu ý:")
        for iss in issues[:10]:
            print(f"  ! {iss}")
        if len(issues) > 10:
            print(f"  ... và {len(issues)-10} vấn đề khác.")
    else:
        if total_files == 0:
            print("Chưa có file âm thanh nào trong các thư mục dataset.")
        else:
            print("Tất cả các file đều hợp lệ về định dạng (16kHz, mono, PCM_16)!")
    print("=" * 60)

if __name__ == "__main__":
    check_dataset()
