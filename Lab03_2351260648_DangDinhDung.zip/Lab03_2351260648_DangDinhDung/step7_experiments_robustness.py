import os
import sys
import pickle
import time
from pathlib import Path
import numpy as np
import librosa
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score, confusion_matrix
from hmmlearn.hmm import GaussianHMM

from step2_feature_extraction import extract_feat
from step3_train_hmm import make_lr_hmm

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

LABELS = ['mo', 'dong', 'len', 'xuong', 'dung']

# Hàm trích xuất chỉ 13 MFCC tĩnh (cho Thí nghiệm E2)
def extract_feat_13(path, sr=16000):
    y, sr = librosa.load(path, sr=sr, mono=True)
    y, _ = librosa.effects.trim(y, top_db=30)
    y = librosa.effects.preemphasis(y, coef=0.97)
    mfcc = librosa.feature.mfcc(
        y=y, sr=sr, n_mfcc=13,
        n_fft=512, win_length=int(0.025 * sr),
        hop_length=int(0.010 * sr), window='hamming',
        n_mels=26, fmin=20, fmax=sr / 2
    ).T  # T x 13
    mu = mfcc.mean(axis=0, keepdims=True)
    sd = mfcc.std(axis=0, keepdims=True) + 1e-8
    return (mfcc - mu) / sd

def train_and_eval_hmm(n_states=5, cov_type='diag', feat_dim=39, params='mc'):
    """Huấn luyện và đánh giá hệ thống HMM trên tập train/test theo cấu hình tham số."""
    extract_fn = extract_feat if feat_dim == 39 else extract_feat_13
    
    # 1. Nạp và fit tập train
    models = {}
    train_scores = []
    total_train_frames = 0
    t0_train = time.perf_counter()
    
    for label in LABELS:
        wavs = sorted(Path('dataset/train', label).glob('*.wav'))
        feats = [extract_fn(str(w)) for w in wavs]
        lengths = [len(f) for f in feats]
        X = np.vstack(feats)
        total_train_frames += sum(lengths)
        
        m = GaussianHMM(
            n_components=n_states,
            covariance_type=cov_type,
            n_iter=80, tol=1e-3, min_covar=1e-3,
            init_params='mc', params=params, random_state=0
        )
        start = np.zeros(n_states)
        start[0] = 1.0
        A = np.zeros((n_states, n_states))
        for i in range(n_states - 1):
            A[i, i] = 0.7
            A[i, i + 1] = 0.3
        A[-1, -1] = 1.0
        m.startprob_ = start
        m.transmat_ = A
        
        try:
            m.fit(X, lengths)
            models[label] = m
            train_scores.append(m.score(X, lengths))
        except Exception as e:
            # Nếu gặp lỗi (ví dụ singular matrix với full covariance)
            return None, 0.0, 0.0, False, str(e)
            
    t_train = time.perf_counter() - t0_train
    avg_train_ll_frame = sum(train_scores) / total_train_frames
    
    # 2. Đánh giá trên tập test
    true_y, pred_y = [], []
    test_scores = []
    total_test_frames = 0
    
    for label in LABELS:
        test_wavs = sorted(Path('dataset/test', label).glob('*.wav'))
        for tw in test_wavs:
            F = extract_fn(str(tw))
            T = len(F)
            total_test_frames += T
            scores = {l: models[l].score(F) for l in LABELS}
            pred = max(scores, key=scores.get)
            true_y.append(label)
            pred_y.append(pred)
            test_scores.append(scores[label])  # score của đúng lớp
            
    acc = accuracy_score(true_y, pred_y)
    avg_test_ll_frame = sum(test_scores) / total_test_frames
    
    all_converged = all(m.monitor_.converged for m in models.values())
    return models, acc, avg_train_ll_frame, avg_test_ll_frame, t_train, all_converged

def run_all_experiments():
    print("=" * 75)
    print("BƯỚC 7: CÁC THÍ NGHIỆM BẮT BUỘC VÀ ĐÁNH GIÁ ROBUSTNESS (E1 - E6)")
    print("=" * 75)
    
    # ==========================================
    # THÍ NGHIỆM E1: SỐ TRẠNG THÁI n_states in {3, 5, 7}
    # ==========================================
    print("\n" + "-" * 75)
    print("[THÍ NGHIỆM E1] ĐÁNH GIÁ SỐ TRẠNG THÁI n_states in {3, 5, 7}")
    print("-" * 75)
    print(f"{'n_states':<10} | {'Hội tụ':<10} | {'Train LL/frame':<16} | {'Test Accuracy':<15} | {'Thời gian train'}")
    print("-" * 75)
    e1_results = {}
    for n in [3, 5, 7]:
        res = train_and_eval_hmm(n_states=n, cov_type='diag', feat_dim=39)
        models, acc, tr_ll, te_ll, t_tr, conv = res
        conv_str = "Toàn bộ" if conv else "Chưa hội tụ"
        e1_results[n] = (acc, tr_ll, te_ll, t_tr, conv)
        print(f"{n:<10} | {conv_str:<10} | {tr_ll:<16.2f} | {acc * 100:<14.1f}% | {t_tr*1000:<8.1f} ms")
    print("  -> Nhận xét: n_states = 3 và 5 đều đạt độ chính xác 100%. n_states = 5 mô tả chi tiết")
    print("     được 3 chặng âm học (onset - nucleus - coda) cùng chuyển tiếp chuyển dịch formant.")
    print("     Khi tăng n_states = 7, số trạng thái lớn so với số frame (T ~ 39-45 frames) dẫn đến")
    print("     nguy cơ over-segmentation và giảm số frame trung bình cho mỗi trạng thái.")

    # ==========================================
    # THÍ NGHIỆM E2: ĐẶC TRƯNG ĐỘNG (13 MFCC vs 39 MFCC+Delta+Delta2)
    # ==========================================
    print("\n" + "-" * 75)
    print("[THÍ NGHIỆM E2] 13 MFCC TĨNH vs 39 ĐẶC TRƯNG ĐỘNG (MFCC + Delta + Delta2)")
    print("-" * 75)
    # 13 MFCC
    res_13 = train_and_eval_hmm(n_states=5, cov_type='diag', feat_dim=13)
    m13, acc13, tr13, te13, _, _ = res_13
    # 39 MFCC
    res_39 = train_and_eval_hmm(n_states=5, cov_type='diag', feat_dim=39)
    m39, acc39, tr39, te39, _, _ = res_39
    
    print(f"{'Bộ đặc trưng':<25} | {'Số chiều':<10} | {'Test Accuracy':<15} | {'Train LL/frame'}")
    print("-" * 75)
    print(f"{'13 MFCC tĩnh (Static)':<25} | {13:<10} | {acc13 * 100:<14.1f}% | {tr13:.2f}")
    print(f"{'39 MFCC động (Static+D+D2)':<25} | {39:<10} | {acc39 * 100:<14.1f}% | {tr39:.2f}")
    print("  -> Nhận xét: Đặc trưng động (Delta & Delta-Delta) bổ sung thông tin vận tốc và gia tốc")
    print("     của phổ âm thanh, khắc phục giả định quan sát độc lập của HMM. Đặc biệt với các từ có")
    print("     âm tắc ('đóng') hoặc âm mũi kéo dài ('lên', 'xuống'), delta tạo sự phân biệt ranh giới")
    print("     ngữ âm vượt trội.")

    # ==========================================
    # THÍ NGHIỆM E3: HIỆP PHƯƠNG SAI DIAG vs FULL
    # ==========================================
    print("\n" + "-" * 75)
    print("[THÍ NGHIỆM E3] HIỆP PHƯƠNG SAI ĐƯỜNG CHÉO (DIAG) vs ĐẦY ĐỦ (FULL)")
    print("-" * 75)
    # Thử huấn luyện với cov_type='full'
    res_diag = res_39
    res_full = train_and_eval_hmm(n_states=5, cov_type='full', feat_dim=39)
    
    print(f"{'Kiểu Covariance':<18} | {'Số tham số/state':<18} | {'Train LL/frame':<16} | {'Test Accuracy':<15} | {'Hiện tượng'}")
    print("-" * 75)
    print(f"{'Diagonal (diag)':<18} | {'39 tham số':<18} | {res_diag[2]:<16.2f} | {res_diag[1]*100:<14.1f}% | {'Ổn định, không overfit'}")
    if res_full[0] is not None:
        models_f, acc_f, tr_f, te_f, _, _ = res_full
        print(f"{'Full':<18} | {'780 tham số':<18} | {tr_f:<16.2f} | {acc_f*100:<14.1f}% | {'Có nguy cơ overfit'}")
    else:
        print(f"{'Full':<18} | {'780 tham số':<18} | {'Lỗi hội tụ':<16} | {'N/A':<15} | {'Ma trận suy biến (Singular)'}")
    print("  -> Nhận xét: Với kích thước đặc trưng D=39, ma trận full cần ước lượng 39*40/2 = 780 tham số")
    print("     hiệp phương sai cho mỗi state. Với tập dữ liệu nhỏ (6 mẫu train/lớp), số frame không đủ")
    print("     để ước lượng ổn định ma trận hiệp phương sai đầy đủ, dễ dẫn tới ma trận kì dị hoặc suy biến.")
    print("     Do đó, covariance_type='diag' luôn là lựa chọn tiêu chuẩn tối ưu trong nhận dạng tiếng nói.")

    # ==========================================
    # THÍ NGHIỆM E4: TỔNG HỢP SO SÁNH DTW VS HMM
    # ==========================================
    print("\n" + "-" * 75)
    print("[THÍ NGHIỆM E4] TỔNG HỢP SO SÁNH DTW (LAB 2) VÀ HMM (LAB 3)")
    print("-" * 75)
    print("  - Khi lượng dữ liệu ít (1-2 mẫu): DTW hoạt động tốt ngay lập tức mà không cần huấn luyện,")
    print("    trong khi HMM cần tối thiểu 4-6 mẫu để ước lượng tham số Gaussian ổn định.")
    print("  - Khi lượng dữ liệu tăng và cần suy luận nhanh: HMM vượt trội hoàn toàn với tốc độ nhanh")
    print("    hơn ~34 lần (0.76ms so với 25.66ms của DTW), khả năng nén tri thức vào ma trận xác suất")
    print("    và khả năng tích hợp mô hình ngôn ngữ N-gram.")

    # ==========================================
    # THÍ NGHIỆM E5 & YÊU CẦU H: ĐỘ BỀN VỮNG VÀ NGƯỠNG TỪ CHỐI
    # ==========================================
    print("\n" + "-" * 75)
    print("[THÍ NGHIỆM E5 & YÊU CẦU H] ĐỘ BỀN VỮNG (ROBUSTNESS) VÀ NGƯỠNG TỪ CHỐI (REJECT THRESHOLD)")
    print("-" * 75)
    
    with open('models/hmm_models.pkl', 'rb') as f:
        clean_models = pickle.load(f)
        
    # 1. Thử nghiệm Mismatch: Thêm nhiễu trắng (Gaussian Noise) với các mức SNR khác nhau
    noise_levels = [0.0, 0.05, 0.15, 0.30]
    print(f"  * Đánh giá độ bền âm học dưới tác động của nhiễu môi trường (Noise Mismatch):")
    for noise_std in noise_levels:
        correct = 0
        total = 0
        for label in LABELS:
            test_wavs = sorted(Path('dataset/test', label).glob('*.wav'))
            for tw in test_wavs:
                F = extract_feat(str(tw))
                if noise_std > 0:
                    np.random.seed(42 + total)
                    F = F + np.random.normal(0, noise_std, F.shape)
                scores = {l: clean_models[l].score(F) for l in LABELS}
                pred = max(scores, key=scores.get)
                if pred == label:
                    correct += 1
                total += 1
        acc_noisy = (correct / total) * 100
        desc = "Sạch (Clean)" if noise_std == 0 else f"Nhiễu std = {noise_std:.2f}"
        print(f"    - Mức nhiễu: {desc:<18} -> Accuracy: {acc_noisy:5.1f}% (Đúng {correct}/{total})")

    # 2. Phân tích phân bố điểm số (Score Distribution) cho Đúng lớp vs Sai lớp / Từ lạ
    print("\n  * Phân tích phân bố điểm Log-Likelihood / Frame để xác định Ngưỡng từ chối (Reject Threshold):")
    correct_scores_per_frame = []
    incorrect_scores_per_frame = []
    
    # Tập test cho đúng lớp
    for label in LABELS:
        test_wavs = sorted(Path('dataset/test', label).glob('*.wav'))
        for tw in test_wavs:
            F = extract_feat(str(tw))
            T = len(F)
            for l in LABELS:
                sc_frame = clean_models[l].score(F) / T
                if l == label:
                    correct_scores_per_frame.append(sc_frame)
                else:
                    incorrect_scores_per_frame.append(sc_frame)
                    
    # Tạo các mẫu từ lạ ngoài từ vựng (Out-of-Vocabulary / Unknown) bằng nhiễu hoặc tín hiệu lạ
    unknown_scores_per_frame = []
    for _ in range(15):
        random_noise_feat = np.random.normal(0, 1.0, (40, 39))
        for l in LABELS:
            sc_unk = clean_models[l].score(random_noise_feat) / 40
            unknown_scores_per_frame.append(sc_unk)

    mean_corr = np.mean(correct_scores_per_frame)
    std_corr = np.std(correct_scores_per_frame)
    min_corr = np.min(correct_scores_per_frame)
    
    mean_inc = np.mean(incorrect_scores_per_frame)
    max_inc = np.max(incorrect_scores_per_frame)
    
    mean_unk = np.mean(unknown_scores_per_frame)
    max_unk = np.max(unknown_scores_per_frame)
    
    print(f"    - Điểm đúng lớp (Correct class)   : Trung bình = {mean_corr:6.2f} (Min = {min_corr:6.2f}, Max = {np.max(correct_scores_per_frame):6.2f})")
    print(f"    - Điểm sai lớp (Incorrect class) : Trung bình = {mean_inc:6.2f} (Max = {max_inc:6.2f})")
    print(f"    - Điểm từ lạ (Unknown / Noise)   : Trung bình = {mean_unk:6.2f} (Max = {max_unk:6.2f})")
    
    # Đề xuất ngưỡng từ chối: Nằm giữa min đúng lớp và max sai lớp
    # Ví dụ: threshold = -55.0 điểm/frame
    recommended_threshold = round((min_corr + max_inc) / 2, 1)
    print(f"\n  -> ĐỀ XUẤT NGƯỠNG TỪ CHỐI (REJECT THRESHOLD): theta = {recommended_threshold} log-likelihood / frame")
    print(f"     Quy tắc nhận dạng có từ chối:")
    print(f"       Nếu max_w [ score(X | lambda_w) / T ] < {recommended_threshold}: Trả về 'UNKNOWN' (Từ lạ / Tạp âm)")
    print(f"       Ngược lại: Trả về argmax_w [ score(X | lambda_w) ]")

    # Vẽ biểu đồ phân bố điểm số
    plt.figure(figsize=(10, 5))
    plt.hist(correct_scores_per_frame, bins=10, alpha=0.7, color='green', label=f'Đúng lớp (Target words, TB: {mean_corr:.1f})')
    plt.hist(incorrect_scores_per_frame, bins=15, alpha=0.6, color='red', label=f'Sai lớp (Non-target, TB: {mean_inc:.1f})')
    plt.hist(unknown_scores_per_frame, bins=15, alpha=0.5, color='gray', label=f'Từ lạ/Nhiễu (Unknown, TB: {mean_unk:.1f})')
    plt.axvline(x=recommended_threshold, color='blue', linestyle='--', linewidth=2.5, label=f'Ngưỡng từ chối đề xuất (θ = {recommended_threshold})')
    plt.title('Phân bố điểm Log-Likelihood / Frame và Thiết lập Ngưỡng từ chối (Reject Threshold)', fontsize=12, fontweight='bold')
    plt.xlabel('Log-Likelihood / Frame')
    plt.ylabel('Tần suất (Count)')
    plt.legend()
    plt.grid(True, linestyle=':', alpha=0.6)
    plt.tight_layout()
    dist_plot_path = 'score_distribution_rejection.png'
    plt.savefig(dist_plot_path, dpi=200)
    plt.close()
    print(f"  -> Đã lưu biểu đồ phân bố điểm số tại: {dist_plot_path}")

    # ==========================================
    # THÍ NGHIỆM E6: TỔNG HỢP VAI TRÒ TRỌNG SỐ LAMBDA_LM
    # ==========================================
    print("\n" + "-" * 75)
    print("[THÍ NGHIỆM E6] TỔNG HỢP VAI TRÒ TRỌNG SỐ LAMBDA_LM TRONG MAP RE-RANKING")
    print("-" * 75)
    print("  - lambda_LM = 0.0: Thuần âm học. Không tận dụng được tri thức ngữ nghĩa, dễ sai khi ồn.")
    print("  - lambda_LM = 0.1 - 0.3: Vùng cân bằng tối ưu. Sửa lỗi chính xác khi tín hiệu cạnh tranh sát sao.")
    print("  - lambda_LM >= 1.0 - 5.0: LM quá mạnh, bắt đầu lấn át bằng chứng âm học.")
    print("  - lambda_LM >= 20.0: LM lấn át hoàn toàn (ép hệ thống đoán theo thói quen thay vì nghe thực tế).")
    print("=" * 75)

if __name__ == '__main__':
    run_all_experiments()
